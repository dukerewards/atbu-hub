import React from 'react';
import { motion } from 'motion/react';
import { Shield, BookOpen, ShoppingBag, Zap, Globe, Users } from 'lucide-react';

const FeatureCard = ({ icon: Icon, title, description, delay }: { icon: any, title: string, description: string, delay: number }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    transition={{ duration: 0.8, delay }}
    className="group p-8 rounded-[32px] bg-white dark:bg-white/5 border border-slate-200 dark:border-white/10 hover:border-atbu-gold transition-all duration-500"
  >
    <div className="w-14 h-14 bg-atbu-gold/10 rounded-2xl flex items-center justify-center text-atbu-gold mb-6 group-hover:scale-110 transition-transform duration-500">
      <Icon className="w-7 h-7" />
    </div>
    <h3 className="text-xl font-black uppercase tracking-tight mb-3 text-slate-900 dark:text-white">{title}</h3>
    <p className="text-slate-500 dark:text-slate-400 text-sm leading-relaxed">{description}</p>
  </motion.div>
);

const SectionTitle = ({ children, subtitle }: { children: React.ReactNode, subtitle?: string }) => (
  <div className="mb-16">
    <motion.h2 
      initial={{ opacity: 0, x: -20 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      className="text-4xl md:text-5xl font-black uppercase tracking-tighter text-slate-900 dark:text-white"
    >
      {children}
      <span className="text-atbu-gold">.</span>
    </motion.h2>
    {subtitle && (
      <motion.p 
        initial={{ opacity: 0, x: -20 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
        transition={{ delay: 0.1 }}
        className="text-atbu-gold font-black uppercase tracking-widest text-xs mt-2"
      >
        {subtitle}
      </motion.p>
    )}
  </div>
);

export default function About() {
  return (
    <div className="min-h-screen pt-32 pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Hero Section */}
      <div className="mb-32">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-3xl"
        >
          <p className="text-atbu-gold font-black uppercase tracking-[0.4em] text-xs mb-6">Established 2026</p>
          <h1 className="text-6xl md:text-8xl font-black uppercase tracking-tighter text-slate-900 dark:text-white leading-[0.9] mb-10">
            ATBU Hub: The Standard of Academic Excellence
          </h1>
          <p className="text-xl text-slate-500 dark:text-slate-400 leading-relaxed font-medium">
            Designed for the ambitious and the elite, we provide a centralized ecosystem where knowledge meets innovation.
          </p>
        </motion.div>
      </div>

      {/* The Vision */}
      <section className="mb-32">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
          <SectionTitle subtitle="Philosophy">The Vision</SectionTitle>
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="space-y-6 text-lg text-slate-600 dark:text-slate-400"
          >
            <p>
              ATBU Hub is not just a website; it is the digital heartbeat of the Abubakar Tafawa Balewa University student community. 
            </p>
            <p className="border-l-4 border-atbu-gold pl-6 italic font-medium text-slate-900 dark:text-white">
              We envision a future where every student has instant, unhindered access to the resources that drive their success.
            </p>
          </motion.div>
        </div>
      </section>

      {/* What We Offer */}
      <section className="mb-32">
        <SectionTitle subtitle="Core Pillars">What We Offer</SectionTitle>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <FeatureCard 
            icon={BookOpen}
            title="The Vault"
            description="A high-speed digital library for verified handouts and past questions, organized for peak efficiency."
            delay={0.1}
          />
          <FeatureCard 
            icon={ShoppingBag}
            title="The Market"
            description="A trusted, scam-free space for students to trade and connect within our secure perimeter."
            delay={0.2}
          />
          <FeatureCard 
            icon={Users}
            title="The Community"
            description="Real-time chat spaces and discussion boards designed for collaborative learning and networking."
            delay={0.3}
          />
          <FeatureCard 
            icon={Zap}
            title="The Pulse"
            description="Instant official updates and campus news, delivered with precision to keep you ahead."
            delay={0.4}
          />
        </div>
      </section>

      {/* Our Mission */}
      <section className="mb-32">
        <div className="bg-slate-900 dark:bg-white/5 rounded-[48px] p-12 md:p-24 text-center relative overflow-hidden">
          <div className="absolute top-0 right-0 w-96 h-96 bg-atbu-gold/10 blur-[120px] rounded-full -mr-48 -mt-48" />
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-atbu-gold/5 blur-[120px] rounded-full -ml-48 -mb-48" />
          
          <div className="relative z-10 max-w-2xl mx-auto">
            <SectionTitle subtitle="Commitment">Our Mission</SectionTitle>
            <p className="text-xl md:text-2xl text-slate-300 mb-10 font-medium leading-relaxed">
              To eliminate academic barriers and provide every student with the tools they need to achieve greatness. 
            </p>
            <div className="inline-flex items-center px-8 py-4 bg-atbu-gold text-slate-900 font-black uppercase tracking-widest text-sm rounded-full">
              Built by students, for the elite
            </div>
          </div>
        </div>
      </section>

      {/* Footer-like simple navigation */}
      <div className="pt-20 border-t border-slate-200 dark:border-white/5 flex justify-between items-center">
        <span className="text-[10px] font-black uppercase tracking-[0.5em] text-slate-400">ATBU Hub Protocol v1.0</span>
        <div className="flex space-x-8">
          <Globe className="w-5 h-5 text-atbu-gold opacity-50" />
          <Shield className="w-5 h-5 text-atbu-gold opacity-50" />
        </div>
      </div>
    </div>
  );
}
