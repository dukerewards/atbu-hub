import React, { useState, useEffect } from 'react';
import { collection, query, getDocs, addDoc, serverTimestamp } from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { ShoppingCart, Search, AlertTriangle, User, Tag, Plus, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../contexts/AuthContext';

interface MarketItem {
  id: string;
  name: string;
  price: number;
  description: string;
  category: string;
  sellerName: string;
  sellerId: string;
}

export default function Market() {
  const { user } = useAuth();
  const [items, setItems] = useState<MarketItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [showReportModal, setShowReportModal] = useState(false);
  const [reportData, setReportData] = useState({ userId: '', reason: '', details: '' });
  const [reporting, setReporting] = useState(false);

  useEffect(() => {
    const fetchItems = async () => {
      try {
        const querySnapshot = await getDocs(collection(db, 'marketItems'));
        const fetchedItems = querySnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        })) as MarketItem[];
        setItems(fetchedItems);
      } catch (error) {
        console.error("Error fetching market items:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchItems();
  }, []);

  const handleReport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return alert('Please sign in to report');
    
    setReporting(true);
    try {
      await addDoc(collection(db, 'scamReports'), {
        ...reportData,
        reporterId: user.uid,
        createdAt: serverTimestamp()
      });
      alert('Your report has been submitted for review. Thank you for keeping the community safe.');
      setShowReportModal(false);
      setReportData({ userId: '', reason: '', details: '' });
    } catch (error) {
      console.error("Error reporting scam:", error);
      alert('Failed to submit report. Please try again.');
    } finally {
      setReporting(false);
    }
  };

  const displayItems = items.length > 0 ? items : [
    { id: '1', name: 'MacBook Air M1', price: 450000, description: 'Slightly used, 8GB/256GB', category: 'Tech', sellerName: 'Abubakar I.', sellerId: '123' },
    { id: '2', name: 'Calculus Textbook', price: 5000, description: 'Brand new, 12th Edition', category: 'Books', sellerName: 'Joy O.', sellerId: '456' },
    { id: '3', name: 'Scientific Calculator', price: 12000, description: 'Casio fx-991EX', category: 'Tools', sellerName: 'Musa B.', sellerId: '789' },
  ];

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-white uppercase tracking-tighter">Campus <span className="text-atbu-gold">Market</span></h1>
          <p className="text-white/40 font-medium">Safe student-to-student trading hub.</p>
        </div>
        
        <div className="flex gap-2">
          <button className="flex items-center space-x-2 bg-atbu-gold text-atbu-navy px-4 py-2 rounded-xl font-black text-xs uppercase tracking-widest hover:bg-white hover:text-atbu-navy transition-all shadow-md glow-gold">
            <Plus className="w-5 h-5" />
            <span>List Item</span>
          </button>
          <button 
            onClick={() => setShowReportModal(true)}
            className="flex items-center space-x-2 bg-crimson/10 text-crimson px-4 py-2 rounded-xl font-black text-xs uppercase tracking-widest hover:bg-crimson hover:text-white transition-all border border-crimson/20"
          >
            <AlertTriangle className="w-5 h-5" />
            <span>Report Scam</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {displayItems.map((item) => (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            key={item.id}
            className="premium-card group hover:shadow-2xl transition-all border-white/5 hover:border-atbu-gold/40"
          >
            <div className="aspect-square bg-white/5 relative">
              <div className="absolute top-3 left-3 glass-card !rounded-lg border-white/20 shadow-sm px-2 py-1 text-[8px] font-black uppercase tracking-widest text-atbu-gold flex items-center">
                <Tag className="w-3 h-3 mr-1" /> {item.category}
              </div>
              <div className="w-full h-full flex items-center justify-center text-white/5">
                <ShoppingCart className="w-24 h-24" />
              </div>
            </div>
            
            <div className="p-5">
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-black text-white text-lg group-hover:text-atbu-gold transition-colors uppercase tracking-tight">{item.name}</h3>
                <span className="text-atbu-gold font-black text-xl">₦{item.price.toLocaleString()}</span>
              </div>
              <p className="text-sm text-white/40 line-clamp-2 mb-4 h-10 font-medium italic">"{item.description}"</p>
              
              <div className="flex items-center justify-between pt-4 border-t border-white/5">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 rounded-full bg-atbu-gold/10 flex items-center justify-center">
                    <User className="w-4 h-4 text-atbu-gold" />
                  </div>
                  <span className="text-[10px] font-black uppercase tracking-widest text-white/40">{item.sellerName}</span>
                </div>
                <div className="flex gap-2">
                  <button className="bg-atbu-gold/10 text-atbu-gold px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest hover:bg-atbu-gold hover:text-atbu-navy transition-all">
                    Contact
                  </button>
                  <button 
                    onClick={() => {
                      setReportData({...reportData, userId: item.sellerId});
                      setShowReportModal(true);
                    }}
                    className="p-1.5 rounded-lg text-crimson/40 hover:text-crimson hover:bg-crimson/10 transition-all"
                    title="Report Seller"
                  >
                    <AlertTriangle className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Scam Report Modal */}
      <AnimatePresence>
        {showReportModal && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-atbu-navy/80 backdrop-blur-xl"
          >
            <motion.div 
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 20 }}
              className="premium-card w-full max-w-md p-8 relative"
            >
              <button 
                onClick={() => setShowReportModal(false)}
                className="absolute top-6 right-6 text-white/20 hover:text-white"
              >
                <X className="w-6 h-6" />
              </button>

              <div className="flex items-center space-x-3 text-crimson mb-6 font-black uppercase tracking-widest text-lg">
                <AlertTriangle className="w-6 h-6" />
                <h2>Scam Reporting Facility</h2>
              </div>

              <form onSubmit={handleReport} className="space-y-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40">Target Seller ID or Handle</label>
                  <input 
                    required
                    type="text" 
                    placeholder="@username or UID"
                    className="w-full px-5 py-4 rounded-2xl glass-card border-white/10 outline-none focus:border-atbu-gold transition-all text-white"
                    value={reportData.userId}
                    onChange={e => setReportData({...reportData, userId: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40">Primary Reason</label>
                  <select 
                    required
                    className="w-full px-5 py-4 rounded-2xl glass-card border-white/10 outline-none focus:border-atbu-gold transition-all text-white appearance-none"
                    value={reportData.reason}
                    onChange={e => setReportData({...reportData, reason: e.target.value})}
                  >
                    <option value="" className="bg-charcoal">Select a reason</option>
                    <option value="fake_item" className="bg-charcoal">Fake/Counterfeit Item</option>
                    <option value="payment_scam" className="bg-charcoal">Payment Fraud</option>
                    <option value="no_delivery" className="bg-charcoal">Item Never Delivered</option>
                    <option value="impersonation" className="bg-charcoal">Impersonation</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40">Detailed Evidence</label>
                  <textarea 
                    required
                    rows={4}
                    placeholder="Provide details of the transaction..."
                    className="w-full px-5 py-4 rounded-2xl glass-card border-white/10 outline-none focus:border-atbu-gold transition-all text-white resize-none"
                    value={reportData.details}
                    onChange={e => setReportData({...reportData, details: e.target.value})}
                  />
                </div>
                <button 
                  disabled={reporting}
                  type="submit"
                  className="w-full bg-crimson text-white font-black uppercase tracking-widest text-xs py-5 rounded-2xl hover:scale-[1.02] active:scale-95 transition-all shadow-xl shadow-crimson/20"
                >
                  {reporting ? 'Submitting...' : 'Submit Official Report'}
                </button>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
