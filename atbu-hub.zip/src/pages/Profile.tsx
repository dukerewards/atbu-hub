import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { doc, updateDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { User, Mail, GraduationCap, Award, Save, RefreshCcw, ShieldCheck } from 'lucide-react';
import { motion } from 'motion/react';

export default function Profile() {
  const { user, profile, loading, refreshProfile } = useAuth();
  const [department, setDepartment] = useState(profile?.department || '');
  const [faculty, setFaculty] = useState(profile?.faculty || '');
  const [level, setLevel] = useState((profile as any)?.level || '');
  const [saving, setSaving] = useState(false);

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    
    const docPath = `users/${user.uid}`;
    setSaving(true);
    try {
      await updateDoc(doc(db, 'users', user.uid), {
        department,
        faculty,
        level
      });
      await refreshProfile();
      alert('Profile updated successfully!');
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, docPath);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <RefreshCcw className="w-8 h-8 animate-spin text-atbu-gold" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="text-center py-20 bg-white rounded-3xl border border-slate-100 shadow-sm">
        <User className="w-16 h-16 text-slate-300 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-atbu-navy">Please Sign In</h2>
        <p className="text-slate-500 max-w-md mx-auto mt-2">
          Connect your Google account to access your reputation dashboard and manage your profile.
        </p>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-atbu-navy rounded-3xl p-8 text-white relative overflow-hidden shadow-xl">
        <div className="relative z-10 flex flex-col md:flex-row items-center gap-8">
          <div className="relative">
            {profile?.photoURL ? (
              <img src={profile.photoURL} alt="Profile" className="w-32 h-32 rounded-3xl border-4 border-atbu-gold shadow-lg" />
            ) : (
              <div className="w-32 h-32 rounded-3xl bg-atbu-blue border-4 border-atbu-gold flex items-center justify-center">
                <User className="w-16 h-16 text-atbu-gold" />
              </div>
            )}
            <div className="absolute -bottom-2 -right-2 bg-atbu-gold text-atbu-navy px-3 py-1 rounded-full text-xs font-black shadow-md uppercase tracking-tighter">
              Verified
            </div>
          </div>
          
          <div className="text-center md:text-left">
            <h1 className="text-3xl font-bold">{profile?.displayName}</h1>
            <div className="flex flex-wrap justify-center md:justify-start gap-4 mt-2">
              <span className="flex items-center text-atbu-gold font-medium">
                <Mail className="w-4 h-4 mr-2" /> {profile?.email}
              </span>
              <span className="flex items-center text-atbu-yellow font-bold bg-atbu-blue/50 px-3 py-1 rounded-full text-sm">
                <Award className="w-4 h-4 mr-1" /> {profile?.reputationPoints} Reputation Points
              </span>
            </div>
          </div>
        </div>
        <div className="absolute top-0 right-0 w-64 h-64 bg-atbu-gold/5 blur-3xl rounded-full translate-x-1/2 -translate-y-1/2" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100"
        >
          <div className="flex items-center space-x-2 text-atbu-navy font-bold text-lg mb-6">
            <GraduationCap className="w-6 h-6 text-atbu-gold" />
            <h2>Academic Information</h2>
          </div>
          
          <form onSubmit={handleUpdate} className="space-y-6">
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">Faculty</label>
              <input 
                type="text" 
                placeholder="e.g. Faculty of Engineering"
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-atbu-gold/20 focus:border-atbu-gold outline-none"
                value={faculty}
                onChange={e => setFaculty(e.target.value)}
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">Department</label>
              <input 
                type="text" 
                placeholder="e.g. Computer Engineering"
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-atbu-gold/20 focus:border-atbu-gold outline-none"
                value={department}
                onChange={e => setDepartment(e.target.value)}
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">Academic Level</label>
              <select 
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-atbu-gold/20 focus:border-atbu-gold outline-none bg-white font-medium"
                value={level}
                onChange={e => setLevel(e.target.value)}
              >
                <option value="">Select Level</option>
                <option value="100">100 Level</option>
                <option value="200">200 Level</option>
                <option value="300">300 Level</option>
                <option value="400">400 Level</option>
                <option value="500">500 Level</option>
                <option value="PG">Postgraduate</option>
              </select>
            </div>
            <button 
              disabled={saving}
              type="submit"
              className="w-full bg-atbu-navy text-atbu-gold font-bold py-3 rounded-xl hover:bg-atbu-blue hover:text-white transition-all shadow-md flex items-center justify-center space-x-2"
            >
              <Save className="w-5 h-5" />
              <span>{saving ? 'Saving...' : 'Save Updates'}</span>
            </button>
          </form>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100"
        >
          <div className="flex items-center space-x-2 text-atbu-navy font-bold text-lg mb-6">
            <ShieldCheck className="w-6 h-6 text-atbu-gold" />
            <h2>Contributor Status</h2>
          </div>
          <div className="space-y-4">
            <div className={`p-4 rounded-2xl border ${profile?.isContributor ? 'bg-green-50 border-green-100 text-green-800' : 'bg-slate-50 border-slate-100 text-slate-600'}`}>
              <p className="font-bold flex items-center">
                {profile?.isContributor ? (
                  <>
                    <Award className="w-5 h-5 mr-2" /> Contributor Mode Active
                  </>
                ) : (
                  'Standard Member'
                )}
              </p>
              <p className="text-sm mt-1">
                {profile?.isContributor 
                  ? 'You can upload manuals and textbooks to the library.' 
                  : 'Earn 100 reputation points to become a recognized contributor.'}
              </p>
            </div>
            
            <div className="bg-atbu-blue/5 p-6 rounded-2xl">
              <h4 className="font-bold text-atbu-navy mb-2">How to earn points:</h4>
              <ul className="text-sm text-slate-600 space-y-2">
                <li className="flex items-start">
                  <span className="w-1.5 h-1.5 rounded-full bg-atbu-gold mt-1.5 mr-2 flex-shrink-0" />
                  <span>Upload a verified course manual (+20 pts)</span>
                </li>
                <li className="flex items-start">
                  <span className="w-1.5 h-1.5 rounded-full bg-atbu-gold mt-1.5 mr-2 flex-shrink-0" />
                  <span>Report a verified scammer (+10 pts)</span>
                </li>
                <li className="flex items-start">
                  <span className="w-1.5 h-1.5 rounded-full bg-atbu-gold mt-1.5 mr-2 flex-shrink-0" />
                  <span>Help a fellow student (+5 pts)</span>
                </li>
              </ul>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
