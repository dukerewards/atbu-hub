import React, { useState, useEffect } from 'react';
import { collection, getDocs, updateDoc, doc, increment } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Award, BookOpen, Clock, PlayCircle, Star, ChevronLeft } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { CBTQuizEngine } from '../components/CBTQuizEngine';
import { useAuth } from '../contexts/AuthContext';

interface Question {
  question: string;
  options: string[];
  correctAnswer: number;
}

interface Quiz {
  id: string;
  title: string;
  courseCode: string;
  questions: Question[];
}

export default function Quizzes() {
  const { user, refreshProfile } = useAuth();
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeQuiz, setActiveQuiz] = useState<Quiz | null>(null);

  useEffect(() => {
    const fetchQuizzes = async () => {
      try {
        const querySnapshot = await getDocs(collection(db, 'quizzes'));
        const fetched = querySnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        })) as Quiz[];
        setQuizzes(fetched);
      } catch (error) {
        console.error("Error fetching quizzes:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchQuizzes();
  }, []);

  const handleQuizComplete = async (score: number) => {
    if (user && activeQuiz) {
      // Reward reputation points for completing a quiz (e.g., 5 points)
      try {
        await updateDoc(doc(db, 'users', user.uid), {
          reputationPoints: increment(5)
        });
        await refreshProfile();
      } catch (err) {
        console.error('Failed to reward points', err);
      }
    }
  };

  const displayQuizzes = quizzes.length > 0 ? quizzes : [
    { 
      id: '1', 
      title: 'Calculus Fundamentals', 
      courseCode: 'MTH 101',
      questions: [
        { question: 'What is the derivative of x^2?', options: ['x', '2x', 'x^2', '2'], correctAnswer: 1 },
        { question: 'What is the integral of 1/x?', options: ['ln(x)', 'e^x', 'x', '1'], correctAnswer: 0 }
      ]
    },
    { 
      id: '2', 
      title: 'Intro to Engineering', 
      courseCode: 'ENG 101',
      questions: [
        { question: 'Which law relates voltage, current, and resistance?', options: ["Newton's Law", "Ohm's Law", "Hooke's Law", "Boyle's Law"], correctAnswer: 1 }
      ]
    },
    { 
      id: '3', 
      title: 'General Physics I', 
      courseCode: 'PHY 101',
      questions: [
        { question: 'The rate of change of displacement is called?', options: ['Speed', 'Acceleration', 'Velocity', 'Momentum'], correctAnswer: 2 }
      ]
    },
  ];

  if (activeQuiz) {
    return (
      <CBTQuizEngine 
        courseCode={activeQuiz.courseCode}
        title={activeQuiz.title}
        questions={activeQuiz.questions}
        onComplete={handleQuizComplete}
        onExit={() => setActiveQuiz(null)}
      />
    );
  }

  return (
    <div className="space-y-8">
      <div className="bg-gradient-to-r from-atbu-navy to-atbu-blue rounded-3xl p-8 md:p-12 text-white shadow-xl relative overflow-hidden">
        <div className="relative z-10 max-w-xl">
          <h1 className="text-4xl font-bold mb-4">CBT Practice Center</h1>
          <p className="text-atbu-gold text-lg font-medium"> Master your courses with interactive practice tests designed for ATBU exams.</p>
        </div>
        <Award className="absolute right-8 top-1/2 -translate-y-1/2 w-48 h-48 text-white/5" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {displayQuizzes.map((quiz) => (
          <motion.div
            whileHover={{ scale: 1.02 }}
            key={quiz.id}
            className="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="bg-atbu-gold/10 text-atbu-gold px-3 py-1 rounded-lg text-xs font-black uppercase">
                  {quiz.courseCode}
                </span>
                <div className="flex items-center text-slate-400 text-xs font-medium">
                  <Clock className="w-4 h-4 mr-1" /> 20 Mins
                </div>
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-2">{quiz.title}</h3>
              <div className="flex items-center space-x-4 text-sm text-slate-500 mb-6">
                <span className="flex items-center"><BookOpen className="w-4 h-4 mr-1" /> {quiz.questions.length} Questions</span>
                <span className="flex items-center"><Star className="w-4 h-4 mr-1 text-atbu-gold" /> 4.8 Rating</span>
              </div>
            </div>
            
            <button 
              onClick={() => setActiveQuiz(quiz)}
              className="w-full bg-atbu-navy text-white font-bold py-3 rounded-xl hover:bg-atbu-blue transition-all flex items-center justify-center space-x-2 group"
            >
              <PlayCircle className="w-5 h-5 group-hover:text-atbu-gold" />
              <span>Start Practice</span>
            </button>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
