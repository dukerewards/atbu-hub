import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAdminGuard } from '../hooks/useAdminGuard';
import { AdminLayout } from '../components/admin/AdminLayout';
import { ApprovalQueue } from '../components/admin/ApprovalQueue';
import { UserManagement } from '../components/admin/UserManagement';
import { NewsManager } from '../components/admin/NewsManager';
import { StorageMonitor } from '../components/admin/StorageMonitor';
import { AnalyticsPanel } from '../components/admin/AnalyticsPanel';
import { MarketModeration } from '../components/admin/MarketModeration';

export default function AdminDashboard() {
  const { isAdmin, loading } = useAdminGuard();

  if (loading) {
    return (
      <div className="min-h-screen bg-[#050505] flex items-center justify-center">
        <div className="w-16 h-16 border-t-4 border-atbu-gold border-solid rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!isAdmin) {
    return <Navigate to="/" replace />;
  }

  return (
    <AdminLayout>
      <Routes>
        <Route index element={<AnalyticsPanel />} />
        <Route path="approvals" element={<ApprovalQueue />} />
        <Route path="users" element={<UserManagement />} />
        <Route path="news" element={<NewsManager />} />
        <Route path="market" element={<MarketModeration />} />
        <Route path="storage" element={<StorageMonitor />} />
      </Routes>
    </AdminLayout>
  );
}
