import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { BookOpen, ShoppingBag, Award, GraduationCap, ChevronRight, Search, Lock, Star, Users, Zap, ArrowUpRight, TrendingUp, Plus } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { NoticeBoard } from '../components/NoticeBoard';
import { useAuth } from '../contexts/AuthContext';
import { LoginModal } from '../components/LoginModal';
import { cn } from '../lib/utils';
import { collection, query, orderBy, limit, getDocs, where } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';

export default function Home() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [leaderboard, setLeaderboard] = useState<any[]>([]);

  useEffect(() => {
    const fetchTopStudents = async () => {
      const collPath = 'users';
      try {
        const q = query(
          collection(db, 'users'), 
          where('isBanned', '==', false),
          orderBy('reputationPoints', 'desc'), 
          limit(3)
        );
        const snap = await getDocs(q);
        setLeaderboard(snap.docs.map(doc => doc.data()));
      } catch (err) {
        handleFirestoreError(err, OperationType.LIST, collPath);
      }
    };
    fetchTopStudents();
  }, []);

  const handleAction = (path: string) => {
    if (!user) {
      setIsLoginModalOpen(true);
    } else {
      navigate(path);
    }
  };

  const manualShowcase = [
    { code: 'MTH 101', title: 'Calculus I', color: 'from-blue-600/20 to-atbu-gold/10' },
    { code: 'CHM 101', title: 'General Chemistry', color: 'from-emerald-600/20 to-atbu-gold/10' },
    { code: 'ENG 101', title: 'Intro to Engineering', color: 'from-red-600/20 to-atbu-gold/10' },
    { code: 'GNS 101', title: 'History of Nigeria', color: 'from-purple-600/20 to-atbu-gold/10' },
  ];

  const searchResults = searchQuery 
    ? manualShowcase.filter(m => m.code.toLowerCase().includes(searchQuery.toLowerCase()) || m.title.toLowerCase().includes(searchQuery.toLowerCase()))
    : [];

  return (
    <div className="space-y-24 pb-20">
      <LoginModal 
        isOpen={isLoginModalOpen} 
        onClose={() => setIsLoginModalOpen(false)} 
      />

      {/* Luxury Hero Section */}
      <section className="relative min-h-[80vh] flex flex-col items-center justify-center text-center px-4 overflow-hidden -mx-4 md:-mx-8">
        {/* Animated Background Lights */}
        <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-atbu-gold/10 rounded-full blur-[120px] animate-pulse" />
        <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] bg-blue-600/10 rounded-full blur-[120px] animate-pulse delay-1000" />
        
        <div className="relative z-10 max-w-4xl space-y-8 flex flex-col items-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-32 h-32 md:w-52 md:h-52 bg-white rounded-[40px] p-4 shadow-2xl border border-atbu-gold/40 mb-4 flex items-center justify-center overflow-hidden glow-gold-lg"
          >
            <img 
              src="https://drive.google.com/uc?export=view&id=1_oU9oMI88OxBqNHN3zmXO5TpdOufRJlV" 
              alt="ATBU Official Logo" 
              referrerPolicy="no-referrer"
              className="w-full h-full object-contain"
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center space-x-2 px-6 py-2 rounded-full border border-atbu-gold/40 bg-atbu-gold/10 backdrop-blur-md text-atbu-gold"
          >
            <Zap className="w-4 h-4 fill-current" />
            <span className="text-[10px] font-black uppercase tracking-[0.3em]">The Academic Superbeast 1.0</span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-5xl md:text-8xl font-black text-white leading-none tracking-tighter"
          >
            DIGITAL <span className="text-atbu-gold">EXCELLENCE</span> <br />
            FOR ATBU ELITE
          </motion.h1>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="relative max-w-2xl mx-auto group"
          >
            <div className="absolute -inset-1 bg-gradient-to-r from-atbu-gold via-white/20 to-atbu-gold rounded-[30px] blur opacity-20 group-hover:opacity-40 transition-opacity" />
            <div className="relative glass-card !rounded-[30px] p-2 flex items-center shadow-2xl">
              <Search className="w-6 h-6 text-atbu-gold ml-6 shrink-0" />
              <input 
                type="text" 
                placeholder="Search Course Code (e.g. MTH 101)..."
                className="w-full bg-transparent px-6 py-4 text-white text-lg font-bold outline-none placeholder:text-white/20"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <button 
                onClick={() => handleAction('/library')}
                className="bg-atbu-gold text-atbu-navy px-8 py-4 rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-white hover:text-atbu-navy transition-all active:scale-95 glow-gold shadow-atbu-gold/40"
              >
                Search
              </button>
            </div>

            {/* Search Results Preview */}
            <AnimatePresence>
              {searchQuery && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="absolute top-full left-0 w-full mt-4 bg-white dark:bg-atbu-navy/95 backdrop-blur-2xl border border-slate-200 dark:border-white/10 rounded-[30px] p-4 shadow-2xl z-50 divide-y divide-slate-100 dark:divide-white/5 overflow-hidden"
                >
                  {searchResults.map((res, i) => (
                    <div key={i} className="flex items-center justify-between p-4 group cursor-pointer hover:bg-slate-50 dark:hover:bg-white/5 transition-colors">
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-slate-100 dark:bg-white/5 rounded-xl flex items-center justify-center font-black text-atbu-gold border border-slate-200 dark:border-white/5">
                          {res.code[0]}
                        </div>
                        <div className="text-left">
                          <p className="text-slate-900 dark:text-white font-bold">{res.code}</p>
                          <p className="text-slate-400 dark:text-white/40 text-xs">{res.title}</p>
                        </div>
                      </div>
                      <button 
                        onClick={() => handleAction('/library')}
                        className="flex items-center space-x-2 bg-atbu-gold/10 text-atbu-gold px-4 py-2 rounded-lg text-xs font-black group-hover:bg-atbu-gold group-hover:text-atbu-navy transition-all"
                      >
                        <Lock className="w-3 h-3" />
                        <span>VIEW</span>
                      </button>
                    </div>
                  ))}
                  {searchResults.length === 0 && (
                    <div className="p-8 text-center text-white/40 italic">
                      No matches found. Search the full library!
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>
      </section>

      {/* Campus Heritage Section - Luxury Edition */}
      <section className="relative py-24 -mx-4 md:-mx-8 overflow-hidden">
        {/* Decorative Background Elements */}
        <div className="absolute top-0 right-0 w-full h-full bg-atbu-navy/5 dark:bg-white/2 select-none pointer-events-none" />
        
        {/* New Institutional Background Image */}
        <div 
          className="absolute right-0 bottom-0 w-full h-full opacity-[0.08] pointer-events-none z-0 mix-blend-overlay grayscale"
          style={{ 
            backgroundImage: `url('https://drive.google.com/uc?export=view&id=1VtUB-jYfb-M_djYNLrGHglxLK4iW00AY')`,
            backgroundPosition: 'right bottom',
            backgroundSize: '80% auto',
            backgroundRepeat: 'no-referrer no-repeat'
          }}
        />

        <div className="absolute left-0 top-1/2 -translate-y-1/2 w-px h-64 bg-gradient-to-b from-transparent via-atbu-gold to-transparent opacity-30" />
        <div className="absolute right-0 top-1/2 -translate-y-1/2 w-px h-64 bg-gradient-to-b from-transparent via-atbu-gold to-transparent opacity-30" />

        <div className="max-w-7xl mx-auto px-4 relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-12">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="space-y-6"
            >
              <div className="flex items-center space-x-4">
                <div className="h-[1px] w-12 bg-atbu-gold/40" />
                <span className="text-atbu-gold font-black uppercase tracking-[0.4em] text-[10px] serif italic">The Legacy of Excellence</span>
              </div>
              <h2 className="text-5xl md:text-7xl font-serif text-slate-900 dark:text-white leading-tight">
                Our Campus <br />
                <span className="italic text-atbu-gold">Heritage</span>
              </h2>
              <p className="text-slate-500 dark:text-white/60 text-lg leading-relaxed font-light max-w-lg">
                Established in 1980 as a pinnacle of technological advancement, 
                Abubakar Tafawa Balewa University stands as a living tribute 
                to Nigeria's first Prime Minister.
              </p>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="grid grid-cols-2 gap-8"
            >
              <div className="space-y-2">
                <p className="text-3xl font-serif text-atbu-gold">1980</p>
                <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 dark:text-white/20">Year Founded</p>
              </div>
              <div className="space-y-2">
                <p className="text-3xl font-serif text-atbu-gold">Prime</p>
                <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 dark:text-white/20">Minister Legacy</p>
              </div>
              <div className="space-y-2">
                <p className="text-3xl font-serif text-atbu-gold">Elite</p>
                <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 dark:text-white/20">Technology Hub</p>
              </div>
              <div className="space-y-2">
                <p className="text-3xl font-serif text-atbu-gold">Bauchi</p>
                <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 dark:text-white/20">Heritage Site</p>
              </div>
            </motion.div>
          </div>

          <div className="relative">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="relative aspect-square md:aspect-[4/5] rounded-[60px] overflow-hidden border border-atbu-gold/20 shadow-2xl group"
            >
              <img 
                src="https://images.unsplash.com/photo-1541339907198-e08756ebafe3?auto=format&fit=crop&q=80&w=2070" 
                alt="ATBU Historic Landmark" 
                className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-atbu-navy via-transparent to-transparent opacity-60" />
              <div className="absolute bottom-12 left-12 right-12">
                <div className="p-6 bg-white/10 backdrop-blur-xl border border-white/20 rounded-[30px] space-y-2">
                  <p className="text-white font-serif text-xl">The Gubi Campus</p>
                  <p className="text-atbu-gold/80 text-[10px] uppercase font-black tracking-widest">Bauchi State, Nigeria</p>
                </div>
              </div>
            </motion.div>

            {/* Small Floating Image */}
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.4 }}
              className="absolute -bottom-8 -left-8 w-48 h-48 rounded-[40px] border-4 border-white dark:border-atbu-navy overflow-hidden shadow-2xl hidden md:block"
            >
              <img 
                src="https://images.unsplash.com/photo-1523050853063-88022e0198a0?auto=format&fit=crop&q=80&w=2070" 
                alt="Heritage Detail" 
                className="w-full h-full object-cover"
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Library Showcase */}
      <section className="space-y-8">
        <div className="flex items-end justify-between">
          <div className="space-y-2">
            <span className="text-atbu-gold font-black uppercase tracking-[0.2em] text-xs">Verified Resources</span>
            <h2 className="text-4xl font-black text-slate-900 dark:text-white">Library Showcase</h2>
          </div>
          <div className="flex items-center space-x-4">
            <button 
              onClick={() => {
                if (!user) setIsLoginModalOpen(true);
                else {
                  const navUploadBtn = document.querySelector('[title="Upload Document"]') as HTMLButtonElement;
                  if (navUploadBtn) navUploadBtn.click();
                }
              }}
              className="hidden md:flex items-center space-x-2 bg-atbu-gold/10 text-atbu-gold px-6 py-2.5 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-atbu-gold hover:text-atbu-navy transition-all shadow-lg"
            >
              <Plus className="w-4 h-4" />
              <span>Contribute</span>
            </button>
            <button 
              onClick={() => handleAction('/library')}
              className="flex items-center space-x-2 text-slate-400 dark:text-white/40 hover:text-atbu-gold font-black tracking-widest text-xs uppercase transition-colors"
            >
              <span>Explore All</span>
              <TrendingUp className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {manualShowcase.map((manual, i) => (
            <motion.div
              key={i}
              whileHover={{ y: -10 }}
              onClick={() => handleAction('/library')}
              className={cn(
                "group relative aspect-[3/4] premium-card overflow-hidden cursor-pointer bg-gradient-to-br",
                manual.color
              )}
            >
              <div className="absolute inset-0 bg-atbu-navy/40 backdrop-blur-sm group-hover:backdrop-blur-none transition-all duration-500" />
              <div className="absolute top-8 left-8 text-white">
                <span className="text-3xl font-black tracking-tighter block mb-1 group-hover:text-atbu-gold transition-colors">{manual.code}</span>
                <span className="text-xs font-medium text-white/60">{manual.title}</span>
              </div>
              
              <div className="absolute bottom-8 left-8 right-8 flex items-center justify-between">
                <div className="w-12 h-12 glass-card rounded-2xl flex items-center justify-center text-white">
                  <BookOpen className="w-6 h-6" />
                </div>
                <div className="w-10 h-10 bg-atbu-gold text-atbu-navy rounded-full flex items-center justify-center shadow-lg transform translate-y-20 group-hover:translate-y-0 transition-all duration-500">
                  <ArrowUpRight className="w-5 h-5" />
                </div>
              </div>

              {/* Locked Overlay */}
              {!user && (
                <div className="absolute inset-0 bg-atbu-navy/20 flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="bg-atbu-gold/90 backdrop-blur p-4 rounded-full text-atbu-navy shadow-2xl">
                    <Lock className="w-6 h-6" />
                  </div>
                </div>
              )}
            </motion.div>
          ))}
        </div>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2 space-y-24">
          
          {/* Hall of Fame */}
          <section className="space-y-8">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-atbu-gold/20 rounded-2xl flex items-center justify-center text-atbu-gold">
                <Award className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-2xl font-black text-slate-900 dark:text-white">Reputation Hall of Fame</h3>
                <p className="text-slate-500 dark:text-white/40 text-sm">Recognizing the top contributors of this semester.</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {leaderboard.length > 0 ? leaderboard.map((student, i) => (
                <div key={i} className="glass-card p-6 rounded-[30px] flex flex-col items-center text-center space-y-4 group hover:bg-white/10 transition-all border-atbu-gold/10 hover:border-atbu-gold/40">
                  <div className="relative">
                    <img 
                      src={student.photoURL || `https://ui-avatars.com/api/?name=${student.displayName}&background=d4af37&color=020617`} 
                      alt={student.displayName}
                      className="w-20 h-20 rounded-[25px] object-cover border-2 border-atbu-gold/20"
                    />
                    <div className="absolute -bottom-2 -right-2 bg-atbu-gold text-atbu-navy w-8 h-8 rounded-xl flex items-center justify-center font-black text-xs shadow-lg">
                      #{i + 1}
                    </div>
                  </div>
                  <div>
                    <p className="text-white font-bold group-hover:text-atbu-gold transition-colors">{student.fullName || student.displayName}</p>
                    <p className="text-atbu-gold/60 text-[10px] font-black uppercase tracking-widest">{student.reputationPoints} Points</p>
                  </div>
                </div>
              )) : [1, 2, 3].map(i => (
                <div key={i} className="glass-card p-6 rounded-[30px] flex flex-col items-center text-center space-y-4 pointer-events-none opacity-40">
                  <div className="w-20 h-20 rounded-[25px] bg-white/10 animate-pulse" />
                  <div className="space-y-2 w-full">
                    <div className="h-4 bg-white/10 rounded-full w-2/3 mx-auto" />
                    <div className="h-2 bg-white/5 rounded-full w-1/3 mx-auto" />
                  </div>
                </div>
              ))}
            </div>

            <button 
              onClick={() => handleAction('/leaderboard')}
              className="w-full py-5 glass-card !rounded-[30px] border-atbu-gold/10 text-white font-black uppercase tracking-[0.3em] text-[10px] hover:bg-atbu-gold/10 hover:border-atbu-gold/40 transition-all"
            >
              Enter the Leaderboard
            </button>
          </section>

          {/* Marketplace Snippet (Blurred) */}
          <section className="space-y-8">
            <div className="flex items-center justify-between">
              <h2 className="text-3xl font-black text-slate-900 dark:text-white">Elite Marketplace</h2>
              <div className="flex items-center space-x-2 text-atbu-gold bg-atbu-gold/10 px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest">
                <ShoppingBag className="w-3 h-3" />
                <span>Featured Items</span>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 gap-6 relative">
              <div className="absolute inset-0 z-10 backdrop-blur-md bg-slate-200/20 dark:bg-atbu-navy/20 flex items-center justify-center rounded-[40px]">
                <button 
                  onClick={() => handleAction('/market')}
                  className="bg-slate-900 dark:bg-white text-atbu-gold dark:text-atbu-navy font-black px-12 py-5 rounded-[25px] shadow-2xl hover:bg-atbu-gold transition-all active:scale-95 flex items-center space-x-3"
                >
                  <Lock className="w-4 h-4" />
                  <span>UNLOCK MARKETPLACE</span>
                </button>
              </div>

              {[1, 2, 3].map(i => (
                <div key={i} className="bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-[40px] p-6 space-y-4 filter blur-[2px]">
                   <div className="aspect-square bg-slate-200 dark:bg-white/5 rounded-[30px]" />
                   <div className="space-y-2">
                     <div className="h-4 bg-slate-200 dark:bg-white/10 rounded-full w-2/3" />
                     <div className="h-3 bg-slate-100 dark:bg-white/5 rounded-full w-1/3" />
                   </div>
                </div>
              ))}
            </div>
          </section>

        </div>

        {/* Sidebar */}
        <div className="lg:col-span-1 space-y-8">
          <NoticeBoard />
          
          <div className="bg-gradient-to-br from-atbu-gold/20 to-atbu-navy border border-atbu-gold/20 p-8 rounded-[40px] relative overflow-hidden group">
            <div className="absolute -top-10 -right-10 w-32 h-32 bg-atbu-gold/10 rounded-full blur-3xl group-hover:scale-150 transition-transform duration-700" />
            
            <div className="relative z-10 space-y-6">
              <div className="w-12 h-12 bg-atbu-gold text-atbu-navy rounded-2xl flex items-center justify-center">
                <GraduationCap className="w-6 h-6" />
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-black text-slate-900 dark:text-white">Student Hub Elite</h3>
                <p className="text-slate-500 dark:text-white/60 text-sm leading-relaxed">Join the most advanced digital architecture ever built for ATBU students.</p>
              </div>
              <button 
                onClick={() => handleAction('/profile')}
                className="w-full py-4 bg-atbu-gold text-atbu-navy font-black text-xs uppercase tracking-widest rounded-2xl hover:bg-atbu-navy dark:hover:bg-white hover:text-atbu-gold transition-all shadow-xl shadow-atbu-gold/10"
              >
                Access Profile
              </button>
            </div>
          </div>
        </div>

        {/* Final Luxury CTA */}
        {!user && (
          <section className="lg:col-span-3 relative py-24 overflow-hidden rounded-[50px] border border-atbu-gold/30 bg-slate-100 dark:bg-white/5 backdrop-blur-3xl text-center">
            {/* School Campus Background */}
            <div className="absolute inset-0 opacity-10 dark:opacity-[0.15] grayscale mix-blend-overlay pointer-events-none">
              <img 
                src="https://drive.google.com/uc?export=view&id=1VtUB-jYfb-M_djYNLrGHglxLK4iW00AY" 
                className="w-full h-full object-cover" 
                alt="ATBU Campus" 
              />
            </div>
            <div className="absolute inset-0 bg-gradient-to-b from-atbu-gold/10 to-transparent pointer-events-none" />
            <div className="relative z-10 max-w-4xl mx-auto px-6 space-y-8">
              <div className="flex flex-col items-center space-y-8">
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  className="w-full max-w-lg aspect-video rounded-[30px] overflow-hidden border-2 border-atbu-gold/20 shadow-2xl"
                >
                  <img 
                    src="https://drive.google.com/uc?export=view&id=1VtUB-jYfb-M_djYNLrGHglxLK4iW00AY" 
                    className="w-full h-full object-cover" 
                    alt="ATBU Campus Main" 
                  />
                </motion.div>

                <div className="w-20 h-20 bg-atbu-gold rounded-[30px] flex items-center justify-center shadow-2xl rotate-3">
                  <Zap className="w-10 h-10 text-atbu-navy fill-current" />
                </div>
              </div>
              
              <div className="space-y-4">
                <h2 className="text-4xl md:text-6xl font-black text-slate-900 dark:text-white tracking-tighter">READY TO JOIN THE ELITE?</h2>
                <p className="text-slate-500 dark:text-white/40 font-medium leading-relaxed max-w-2xl mx-auto">
                  Join thousands of ATBU students accelerating their academic success.
                  Get instant access to everything with a single Google sign-in.
                </p>
              </div>
              <button 
                onClick={() => setIsLoginModalOpen(true)}
                className="group relative px-12 py-6 bg-atbu-gold text-atbu-navy font-black text-sm uppercase tracking-[0.4em] rounded-2xl hover:scale-105 active:scale-95 transition-all shadow-2xl shadow-atbu-gold/20 overflow-hidden"
              >
                <span className="relative z-10">ENTER THE HUB NOW</span>
                <div className="absolute inset-0 bg-slate-900 dark:bg-white translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
              </button>
              <p className="text-[10px] text-slate-400 dark:text-white/20 font-black uppercase tracking-widest">
                Protected by ATBU Academic Security Protocol
              </p>
            </div>
          </section>
        )}

      </div>
    </div>
  );
}

