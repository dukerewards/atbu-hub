import React, { useState, useEffect } from 'react';
import { collection, query, orderBy, limit, getDocs, where } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Award, Star, TrendingUp, User, ShieldCheck, Crown, Medal, Zap } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

interface LeaderboardUser {
  uid: string;
  displayName: string;
  fullName?: string;
  reputationPoints: number;
  department?: string;
  photoURL?: string;
}

export default function Leaderboard() {
  const [topUsers, setTopUsers] = useState<LeaderboardUser[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchLeaderboard = async () => {
      try {
        const q = query(
          collection(db, 'users'),
          where('isBanned', '==', false),
          orderBy('reputationPoints', 'desc'),
          limit(20)
        );
        const querySnapshot = await getDocs(q);
        const users = querySnapshot.docs.map(doc => ({
          uid: doc.id,
          ...doc.data()
        })) as LeaderboardUser[];
        setTopUsers(users);
      } catch (error) {
        console.error("Error fetching leaderboard:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchLeaderboard();
  }, []);

  const displayUsers = topUsers.length > 0 ? topUsers : [];

  return (
    <div className="max-w-5xl mx-auto space-y-12">
      <div className="text-center space-y-4">
        <motion.div
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="inline-flex p-6 rounded-[30px] bg-atbu-gold/10 text-atbu-gold mb-4 border border-atbu-gold/20 shadow-2xl shadow-atbu-gold/5"
        >
          <Crown className="w-16 h-16" />
        </motion.div>
        <h1 className="text-6xl font-black text-slate-900 dark:text-white tracking-tighter">HALL OF <span className="text-atbu-gold">FAME</span></h1>
        <p className="text-slate-400 dark:text-white/40 max-w-lg mx-auto font-medium uppercase tracking-[0.2em] text-[10px]">
          Official recognition of the ATBU Academic elite.
        </p>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-64 bg-slate-100 dark:bg-white/5 animate-pulse rounded-[40px] border border-slate-200 dark:border-white/5" />
          ))}
        </div>
      ) : (
        <div className="space-y-12">
          {/* Top 3 Podium */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-end">
            {displayUsers.slice(0, 3).map((user, index) => {
              const positions = [
                { order: 'order-2 md:scale-110 md:-translate-y-8 z-10', icon: <Crown className="w-8 h-8" />, label: 'Champion', color: 'text-atbu-gold' },
                { order: 'order-1', icon: <Medal className="w-8 h-8" />, label: 'Vice', color: 'text-slate-400' },
                { order: 'order-3', icon: <Medal className="w-8 h-8" />, label: 'Third', color: 'text-orange-400' }
              ];
              const pos = index === 0 ? positions[0] : index === 1 ? positions[1] : positions[2];
              
              return (
                <div key={user.uid} className={cn("relative group", pos.order)}>
                  <div className="absolute -inset-1 bg-gradient-to-b from-atbu-gold/20 to-transparent rounded-[50px] blur-xl opacity-0 group-hover:opacity-100 transition-opacity" />
                  <div className="relative bg-slate-50 dark:bg-white/5 backdrop-blur-2xl border border-slate-200 dark:border-white/10 rounded-[50px] p-10 flex flex-col items-center text-center space-y-6 shadow-2xl">
                    <div className="relative">
                       <img 
                         src={user.photoURL || `https://ui-avatars.com/api/?name=${user.fullName || user.displayName}&background=d4af37&color=020617`} 
                         className="w-24 h-24 rounded-[35px] border-4 border-atbu-gold/20 object-cover shadow-2xl" 
                         alt="" 
                       />
                       <div className={cn("absolute -bottom-4 -right-4 w-12 h-12 rounded-2xl flex items-center justify-center shadow-2xl border-4 border-atbu-navy", index === 0 ? 'bg-atbu-gold text-atbu-navy' : 'bg-slate-200 dark:bg-white/10 text-slate-800 dark:text-white')}>
                         {pos.icon}
                       </div>
                    </div>
                    <div>
                      <p className="text-slate-900 dark:text-white font-black text-xl tracking-tight leading-none mb-1">{user.fullName || user.displayName}</p>
                      <p className="text-slate-400 dark:text-white/40 text-[10px] font-black uppercase tracking-widest">{user.department || 'Elite Hub'}</p>
                    </div>
                    <div className="px-6 py-2 bg-atbu-gold text-atbu-navy rounded-full font-black text-sm shadow-lg shadow-atbu-gold/20">
                      {user.reputationPoints.toLocaleString()} PTS
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* List for the rest */}
          <div className="bg-white dark:bg-white/5 backdrop-blur-3xl rounded-[50px] border border-slate-200 dark:border-white/10 overflow-hidden shadow-2xl">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-slate-50 dark:bg-white/5 border-b border-slate-100 dark:border-white/5">
                    <th className="px-10 py-6 text-left text-[10px] font-black uppercase tracking-[0.3em] text-slate-400 dark:text-white/40">Rank</th>
                    <th className="px-10 py-6 text-left text-[10px] font-black uppercase tracking-[0.3em] text-slate-400 dark:text-white/40">Scholar</th>
                    <th className="px-10 py-6 text-left text-[10px] font-black uppercase tracking-[0.3em] text-slate-400 dark:text-white/40">Department</th>
                    <th className="px-10 py-6 text-right text-[10px] font-black uppercase tracking-[0.3em] text-slate-400 dark:text-white/40">Influence</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-white/5">
                  {displayUsers.slice(3).map((user, index) => (
                    <motion.tr
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: index * 0.05 }}
                      key={user.uid}
                      className="hover:bg-slate-50 dark:hover:bg-white/5 transition-colors group"
                    >
                      <td className="px-10 py-6">
                        <span className="text-slate-300 dark:text-white/20 font-black group-hover:text-atbu-gold transition-colors">#{index + 4}</span>
                      </td>
                      <td className="px-10 py-6">
                        <div className="flex items-center space-x-4">
                          <img 
                            src={user.photoURL || `https://ui-avatars.com/api/?name=${user.fullName || user.displayName}&background=d4af37&color=020617`} 
                            className="w-12 h-12 rounded-2xl grayscale group-hover:grayscale-0 transition-all duration-500 border border-slate-200 dark:border-white/10" 
                            alt="" 
                          />
                          <span className="font-black text-slate-900 dark:text-white group-hover:text-atbu-gold transition-colors">{user.fullName || user.displayName}</span>
                        </div>
                      </td>
                      <td className="px-10 py-6 text-slate-500 dark:text-white/40 font-bold text-xs uppercase tracking-widest">
                        {user.department || 'Academic Elite'}
                      </td>
                      <td className="px-10 py-6 text-right">
                        <div className="inline-flex items-center space-x-2 text-atbu-gold font-black px-4 py-2 bg-atbu-gold/10 rounded-xl">
                          <Zap className="w-4 h-4 fill-current" />
                          <span>{user.reputationPoints.toLocaleString()}</span>
                        </div>
                      </td>
                    </motion.tr>
                  ))}
                  {displayUsers.length === 0 && (
                    <tr>
                      <td colSpan={4} className="px-10 py-20 text-center text-slate-300 dark:text-white/20 font-black uppercase tracking-[0.3em]">
                        Waiting for elite contributors...
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

