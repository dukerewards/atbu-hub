import React, { useState, useEffect, useRef } from 'react';
import { collection, query, orderBy, limit, onSnapshot, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';
import { motion, AnimatePresence } from 'motion/react';
import { Send, User, MessageCircle, Info, Loader2, Hash } from 'lucide-react';
import { cn } from '../lib/utils';
import { formatDistanceToNow } from 'date-fns';

interface ChatMessage {
  id: string;
  userId: string;
  userName: string;
  userPhoto: string;
  text: string;
  createdAt: any;
}

export default function ChatSpace() {
  const { user, profile } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [isSending, setIsSending] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const q = query(
      collection(db, 'chatMessages'),
      orderBy('createdAt', 'desc'),
      limit(50)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetchedMessages = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as ChatMessage[];
      
      setMessages(fetchedMessages.reverse());
      setLoading(false);
      scrollToBottom();
    });

    return () => unsubscribe();
  }, []);

  const scrollToBottom = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !newMessage.trim() || isSending) return;

    setIsSending(true);
    try {
      await addDoc(collection(db, 'chatMessages'), {
        userId: user.uid,
        userName: profile?.fullName || user.displayName || 'Scholar',
        userPhoto: user.photoURL || '',
        text: newMessage.trim(),
        createdAt: serverTimestamp(),
      });
      setNewMessage('');
    } catch (error) {
      console.error("Error sending message:", error);
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="h-[calc(100vh-160px)] flex flex-col max-w-5xl mx-auto bg-white dark:bg-white/5 rounded-[40px] border border-slate-200 dark:border-white/10 shadow-2xl overflow-hidden">
      {/* Header */}
      <div className="p-6 border-b border-slate-100 dark:border-white/5 bg-slate-50/50 dark:bg-white/5 backdrop-blur-md flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-atbu-gold rounded-2xl flex items-center justify-center text-atbu-navy shadow-lg shadow-atbu-gold/20">
            <MessageCircle className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-black text-slate-900 dark:text-white tracking-tight uppercase">Chat Space</h1>
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
              <span className="text-xs text-slate-500 dark:text-white/40 font-bold uppercase tracking-widest">Active Campus Discussion</span>
            </div>
          </div>
        </div>
        
        <button className="p-3 text-slate-400 hover:text-atbu-gold transition-colors">
          <Info className="w-5 h-5" />
        </button>
      </div>

      {/* Messages */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-6 space-y-4 scroll-smooth"
      >
        {loading ? (
          <div className="h-full flex items-center justify-center">
            <Loader2 className="w-8 h-8 animate-spin text-atbu-gold" />
          </div>
        ) : (
          <>
            <div className="text-center py-8">
              <div className="p-4 bg-atbu-gold/10 inline-block rounded-3xl border border-atbu-gold/20">
                <Hash className="w-6 h-6 text-atbu-gold mx-auto mb-2" />
                <p className="text-sm font-bold text-slate-800 dark:text-white">Welcome to the Student Forum</p>
                <p className="text-xs text-slate-500 dark:text-white/40 mt-1 max-w-xs">Respect rules, share information, and connect with fellow ATBU scholars.</p>
              </div>
            </div>

            {messages.map((msg, index) => {
              const isMe = msg.userId === user?.uid;
              return (
                <motion.div
                  initial={{ opacity: 0, y: 10, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  key={msg.id}
                  className={cn(
                    "flex items-end space-x-2",
                    isMe ? "flex-row-reverse space-x-reverse" : "flex-row"
                  )}
                >
                  <img
                    src={msg.userPhoto || ''}
                    alt={msg.userName}
                    className="w-8 h-8 rounded-xl border-2 border-atbu-gold/20 shrink-0"
                    onError={(e) => {
                      e.currentTarget.src = "https://ui-avatars.com/api/?name=" + encodeURIComponent(msg.userName);
                    }}
                  />
                  
                  <div className={cn(
                    "max-w-[70%] space-y-1",
                    isMe ? "items-end" : "items-start"
                  )}>
                    {!isMe && (
                      <span className="text-[10px] font-black text-atbu-gold uppercase tracking-widest ml-2">
                        {msg.userName}
                      </span>
                    )}
                    <div className={cn(
                      "px-4 py-3 rounded-3xl text-sm font-medium shadow-sm",
                      isMe 
                        ? "bg-atbu-gold text-atbu-navy rounded-br-none" 
                        : "bg-slate-100 dark:bg-white/10 text-slate-800 dark:text-white rounded-bl-none"
                    )}>
                      {msg.text}
                    </div>
                    {msg.createdAt && (
                      <span className="text-[8px] text-slate-400 dark:text-white/20 uppercase font-black px-2">
                        {formatDistanceToNow(msg.createdAt.toDate())} ago
                      </span>
                    )}
                  </div>
                </motion.div>
              );
            })}
          </>
        )}
      </div>

      {/* Input */}
      <div className="p-6 bg-slate-50/50 dark:bg-white/5 border-t border-slate-100 dark:border-white/5">
        <form onSubmit={handleSendMessage} className="relative">
          <input
            type="text"
            placeholder={user ? "Type your message to campus..." : "Sign in to join discussion"}
            disabled={!user || isSending}
            className="w-full pl-6 pr-20 py-5 bg-white dark:bg-white/5 border-2 border-slate-100 dark:border-white/10 rounded-full outline-none focus:border-atbu-gold transition-all dark:text-white font-medium"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
          />
          <button
            type="submit"
            disabled={!user || !newMessage.trim() || isSending}
            className="absolute right-3 top-1/2 -translate-y-1/2 p-3 bg-atbu-gold text-atbu-navy rounded-full shadow-lg shadow-atbu-gold/20 hover:scale-105 active:scale-95 transition-all disabled:opacity-50 disabled:scale-100"
          >
            {isSending ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
          </button>
        </form>
      </div>
    </div>
  );
}
