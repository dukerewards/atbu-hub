import React, { useState, useEffect } from 'react';
import { collection, query, getDocs, orderBy, where } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { FileText, Search, Download, Filter, BookOpen, Loader2, Plus } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { ManualReader } from '../components/ManualReader';
import { CommentsSection } from '../components/CommentsSection';

import { cn } from '../lib/utils';

interface LibraryResource {
  id: string;
  title: string;
  courseCode: string;
  department: string;
  fileUrl: string;
  type: string;
  uploaderName?: string;
  year?: string;
}

export default function Library() {
  const [resources, setResources] = useState<LibraryResource[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeType, setActiveType] = useState<string>('all');
  const [loading, setLoading] = useState(true);
  const [activeResource, setActiveResource] = useState<LibraryResource | null>(null);

  useEffect(() => {
    const fetchResources = async () => {
      try {
        const manualsSnap = await getDocs(query(collection(db, 'manuals'), orderBy('courseCode', 'asc')));
        const campusSnap = await getDocs(query(
          collection(db, 'campusContent'), 
          where('type', 'in', ['handout', 'past_question']),
          where('status', '==', 'approved'),
          orderBy('courseCode', 'asc')
        ));
        
        const fetchedManuals = manualsSnap.docs.map(doc => ({
          id: doc.id,
          type: 'handout',
          ...doc.data()
        })) as LibraryResource[];

        const fetchedCampus = campusSnap.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        })) as LibraryResource[];

        setResources([...fetchedManuals, ...fetchedCampus]);
      } catch (error) {
        console.error("Error fetching library resources:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchResources();
  }, []);

  const filteredResources = resources.filter(r => {
    const matchesSearch = r.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         r.courseCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         r.department?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = activeType === 'all' || r.type === activeType;
    return matchesSearch && matchesType;
  }).sort((a, b) => a.courseCode.localeCompare(b.courseCode));

  // Mock data if Firestore is empty for demo/first look
  const displayResources = resources.length > 0 ? filteredResources : [
    { id: '1', title: 'Calculus II', courseCode: 'MTH 202', department: 'Math', fileUrl: '#', type: 'handout' },
    { id: '2', title: 'General Physics I', courseCode: 'PHY 101', department: 'Physics', fileUrl: '#', type: 'past_question' },
    { id: '3', title: 'English Language', courseCode: 'GNS 101', department: 'General', fileUrl: '#', type: 'handout' },
    { id: '4', title: 'Intro to Programming', courseCode: 'COM 101', department: 'Computer', fileUrl: '#', type: 'past_question' },
    { id: '5', title: 'Thermodynamics', courseCode: 'ENG 201', department: 'Engineering', fileUrl: '#', type: 'handout' },
  ].filter(r => {
    const matchesSearch = r.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         r.courseCode.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = activeType === 'all' || r.type === activeType;
    return matchesSearch && matchesType;
  }).sort((a, b) => a.courseCode.localeCompare(b.courseCode));

  const groupedResources = displayResources.reduce((acc, resource) => {
    const letter = resource.courseCode[0].toUpperCase();
    if (!acc[letter]) acc[letter] = [];
    acc[letter].push(resource);
    return acc;
  }, {} as Record<string, LibraryResource[]>);

  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

  const types = [
    { id: 'all', label: 'All Resources' },
    { id: 'handout', label: 'Handouts' },
    { id: 'past_question', label: 'Past Questions' }
  ];

  if (activeResource) {
    return (
      <div className="max-w-6xl mx-auto pb-20">
        <ManualReader 
          manualId={activeResource.id}
          courseCode={activeResource.courseCode}
          title={activeResource.title}
          fileUrl={activeResource.fileUrl}
          onExit={() => setActiveResource(null)}
        />
        <div className="mt-8 px-4">
          <CommentsSection 
            contentId={activeResource.id} 
            title={`Discussion on ${activeResource.courseCode}`} 
          />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
          <h1 className="text-4xl font-black text-white tracking-tighter uppercase">Academic <span className="text-atbu-gold">Vault</span></h1>
          <div className="flex items-center space-x-4 mt-2">
            <p className="text-white/40 font-medium font-serif italic text-lg">Elite handouts and past questions sorted A–Z.</p>
            <div className="h-4 w-px bg-white/10 hidden sm:block" />
            <button 
              onClick={() => {
                // Since modal is in Navbar, we can just trigger a custom event or use the navbar button
                const navUploadBtn = document.querySelector('[title="Upload Document"]') as HTMLButtonElement;
                if (navUploadBtn) navUploadBtn.click();
              }}
              className="text-atbu-gold text-xs font-black uppercase tracking-widest hover:underline transition-all flex items-center"
            >
              <div className="w-5 h-5 rounded-full bg-atbu-gold/10 flex items-center justify-center mr-2">
                <Plus className="w-3 h-3" />
              </div>
              Contribute
            </button>
          </div>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-4 w-full lg:max-w-2xl">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-atbu-gold w-5 h-5" />
            <input
              type="text"
              placeholder="Search Course Code..."
              className="w-full pl-12 pr-4 py-4 rounded-2xl glass-card border-white/5 text-white focus:outline-none focus:border-atbu-gold transition-all"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="flex glass-card p-1.5 rounded-2xl border-white/5">
            {types.map((t) => (
              <button
                key={t.id}
                onClick={() => setActiveType(t.id)}
                className={cn(
                  "px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all",
                  activeType === t.id 
                    ? "bg-atbu-gold text-atbu-navy shadow-lg" 
                    : "text-white/40 hover:text-white"
                )}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="flex flex-wrap gap-1.5 py-4 overflow-x-auto scrollbar-hide">
        {alphabet.map(letter => (
          <button
            key={letter}
            className={cn(
              "w-10 h-10 rounded-xl text-xs font-black transition-all shrink-0",
              groupedResources[letter] 
                ? 'glass-card text-atbu-gold border-atbu-gold shadow-lg shadow-atbu-gold/10' 
                : 'glass-card text-white/10 cursor-not-allowed border-transparent opacity-20'
            )}
          >
            {letter}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <Loader2 className="w-12 h-12 animate-spin text-atbu-gold" />
        </div>
      ) : (
        <div className="space-y-16">
          {Object.entries(groupedResources).sort().map(([letter, group]) => (
            <div key={letter} className="space-y-6">
              <div className="flex items-center space-x-4">
                <span className="text-4xl font-black text-atbu-gold opacity-30">{letter}</span>
                <div className="h-px flex-1 bg-gradient-to-r from-atbu-gold/20 to-transparent" />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {(group as LibraryResource[]).map((resource) => (
                  <motion.div
                    layout
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    key={resource.id}
                    className="premium-card p-6 shadow-sm hover:shadow-2xl transition-all relative overflow-hidden group border-white/5 hover:border-atbu-gold/60"
                  >
                    <div className="flex justify-between items-start mb-6">
                      <div className={cn(
                        "w-12 h-12 rounded-2xl flex items-center justify-center text-white shadow-lg",
                        resource.type === 'handout' ? 'bg-blue-600' : 'bg-emerald-600'
                      )}>
                        {resource.type === 'handout' ? <FileText className="w-6 h-6" /> : <BookOpen className="w-6 h-6" />}
                      </div>
                      <span className="text-[10px] font-black text-atbu-gold px-3 py-1 bg-atbu-gold/10 rounded-full uppercase tracking-widest">
                        {resource.courseCode}
                      </span>
                    </div>
                    
                    <div className="space-y-2">
                      <h3 className="font-black text-white line-clamp-2 leading-tight group-hover:text-atbu-gold transition-colors uppercase tracking-tight">
                        {resource.title}
                      </h3>
                      <p className="text-xs text-white/40 font-bold uppercase tracking-widest leading-loose">
                        {resource.department} {resource.year && `• ${resource.year}`}
                      </p>
                    </div>

                    <div className="flex items-center justify-between mt-8 pt-6 border-t border-white/5">
                      <button 
                        onClick={() => setActiveResource(resource)}
                        className="flex items-center text-xs font-black text-atbu-gold uppercase tracking-[0.2em] hover:scale-105 transition-transform"
                      >
                        <BookOpen className="w-4 h-4 mr-2" /> Study Elite
                      </button>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {displayResources.length === 0 && !loading && (
        <div className="text-center py-20 bg-slate-100 dark:bg-white/5 rounded-3xl">
          <FileText className="w-16 h-16 text-slate-300 dark:text-white/10 mx-auto mb-4" />
          <h3 className="text-xl font-bold text-slate-800 dark:text-white">No results found</h3>
          <p className="text-slate-500 dark:text-white/40">Try searching for a different course code or department.</p>
        </div>
      )}
    </div>
  );
}
