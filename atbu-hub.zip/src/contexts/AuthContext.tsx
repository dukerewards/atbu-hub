import React, { createContext, useContext, useEffect, useState } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { auth, db, messaging, handleFirestoreError, OperationType } from '../lib/firebase';
import { doc, getDoc, setDoc, serverTimestamp, updateDoc } from 'firebase/firestore';
import { getToken } from 'firebase/messaging';

interface UserProfile {
  uid: string;
  displayName: string;
  fullName?: string;
  email: string;
  gender?: string;
  photoURL: string;
  department?: string;
  faculty?: string;
  reputationPoints: number;
  isContributor: boolean;
  role: 'student' | 'contributor' | 'admin';
  isBanned?: boolean;
  fcmToken?: string;
}

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  needsOnboarding: boolean;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  profile: null,
  loading: true,
  refreshProfile: async () => {},
});

export const useAuth = () => useContext(AuthContext);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  const needsOnboarding = !!user && !!profile && (!profile.fullName || !profile.gender);

  const fetchProfile = async (uid: string) => {
    const docPath = `users/${uid}`;
    try {
      const docRef = doc(db, 'users', uid);
      const docSnap = await getDoc(docRef);
      
      let currentProfile: UserProfile;

      if (docSnap.exists()) {
        currentProfile = docSnap.data() as UserProfile;
        setProfile(currentProfile);
      } else {
        // Create initial profile if it doesn't exist
        currentProfile = {
          uid,
          displayName: auth.currentUser?.displayName || 'Student',
          email: auth.currentUser?.email || '',
          photoURL: auth.currentUser?.photoURL || '',
          reputationPoints: 10, // Starting points
          isContributor: false,
          role: 'student',
          isBanned: false,
        };
        try {
          await setDoc(docRef, { ...currentProfile, createdAt: serverTimestamp() });
          setProfile(currentProfile);
        } catch (err) {
          handleFirestoreError(err, OperationType.WRITE, docPath);
        }
      }

      // FCM Token logic
      if (messaging) {
        try {
          const permission = await Notification.requestPermission();
          if (permission === 'granted') {
            const token = await getToken(messaging, { 
              vapidKey: 'BIsy_H-p_0dM8oB_q-_qV_H-Vn_n_Vn_n_V' // Placeholder VAPID key
            });
            if (token && token !== currentProfile.fcmToken) {
              await updateDoc(docRef, { fcmToken: token });
            }
          }
        } catch (err) {
          console.log('FCM not available or permission denied', err);
        }
      }
    } catch (error) {
      console.error('Error fetching profile:', error);
      // We don't necessarily want to throw here as it might break the auth flow, 
      // but we should log it properly.
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setUser(user);
      if (user) {
        await fetchProfile(user.uid);
      } else {
        setProfile(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const refreshProfile = async () => {
    if (user) {
      await fetchProfile(user.uid);
    }
  };

  return (
    <AuthContext.Provider value={{ user, profile, loading, needsOnboarding, refreshProfile }}>
      {children}
    </AuthContext.Provider>
  );
};
