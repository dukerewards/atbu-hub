import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

export const useAdminGuard = () => {
  const { profile, loading, user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading) {
      if (!user || (profile && profile.role !== 'admin' && profile.email !== 'emmanuelnefa2006@gmail.com')) {
        navigate('/');
      }
    }
  }, [profile, loading, user, navigate]);

  return { isAdmin: profile?.role === 'admin' || profile?.email === 'emmanuelnefa2006@gmail.com', loading };
};
