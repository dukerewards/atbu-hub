import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { BookOpen, ChevronLeft, ChevronRight, FileText, Layout, Maximize2, Settings, Bookmark, Shield, Lock, Eye, AlertCircle } from 'lucide-react';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { cn } from '../lib/utils';
import { Document, Page, pdfjs } from 'react-pdf';
import 'react-pdf/dist/Page/AnnotationLayer.css';
import 'react-pdf/dist/Page/TextLayer.css';

// Set up PDF.js worker
pdfjs.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.js`;

interface ManualReaderProps {
  manualId: string;
  courseCode: string;
  title: string;
  fileUrl?: string; // Add optional fileUrl
  onExit: () => void;
}

export const ManualReader: React.FC<ManualReaderProps> = ({ manualId, courseCode, title, fileUrl, onExit }) => {
  const [numPages, setNumPages] = useState<number | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [isBookmarking, setIsBookmarking] = useState(false);
  const [scale, setScale] = useState(1.0);
  const [error, setError] = useState<string | null>(null);

  // Security: Disable Right Click
  useEffect(() => {
    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault();
      return false;
    };
    
    document.addEventListener('contextmenu', handleContextMenu);
    return () => document.removeEventListener('contextmenu', handleContextMenu);
  }, []);

  useEffect(() => {
    const fetchBookmark = async () => {
      if (!auth.currentUser) {
        setLoading(false);
        return;
      }
      
      try {
        const bookmarkId = `${auth.currentUser.uid}_${manualId}`;
        const docRef = doc(db, 'bookmarks', bookmarkId);
        const docSnap = await getDoc(docRef);
        
        if (docSnap.exists()) {
          setCurrentPage(docSnap.data().lastPage || 1);
        }
      } catch (err) {
        console.error('Error fetching bookmark:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchBookmark();
  }, [manualId]);

  const saveBookmark = async (page: number) => {
    if (!auth.currentUser) return;
    setIsBookmarking(true);
    try {
      const bookmarkId = `${auth.currentUser.uid}_${manualId}`;
      await setDoc(doc(db, 'bookmarks', bookmarkId), {
        userId: auth.currentUser.uid,
        manualId,
        lastPage: page,
        updatedAt: serverTimestamp()
      }, { merge: true });
    } catch (err) {
      console.error('Error saving bookmark:', err);
    } finally {
      setIsBookmarking(false);
    }
  };

  const onDocumentLoadSuccess = ({ numPages }: { numPages: number }) => {
    setNumPages(numPages);
    setLoading(false);
    setError(null);
  };

  const onDocumentLoadError = (err: Error) => {
    console.error('PDF Load Error:', err);
    setError('Secure access protocol failed. Please try again or contact administration if this persists.');
    setLoading(false);
  };

  const handlePageChange = (newPage: number) => {
    if (newPage < 1 || (numPages && newPage > numPages)) return;
    setCurrentPage(newPage);
    saveBookmark(newPage);
  };

  return (
    <div className="fixed inset-0 z-[100] bg-[#050810] flex flex-col h-screen overflow-hidden select-none secure-viewer">
      <style dangerouslySetInnerHTML={{ __html: `
        @media print {
          body * { visibility: hidden !important; }
          .secure-viewer { display: none !important; }
        }
        .react-pdf__Page__canvas {
          margin: 0 auto;
          box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
        }
      `}} />

      {/* Header */}
      <div className="bg-[#0A0F1E] border-b border-atbu-gold/10 p-4 flex items-center justify-between shadow-2xl relative z-10">
        <div className="flex items-center space-x-4">
          <button onClick={onExit} className="text-white/60 hover:text-atbu-gold hover:bg-white/5 p-2 rounded-xl transition-all">
            <ChevronLeft className="w-6 h-6" />
          </button>
          <div>
            <div className="flex items-center space-x-2">
              <Shield className="w-4 h-4 text-atbu-gold" />
              <h1 className="text-white font-black text-sm uppercase tracking-tight">{title}</h1>
            </div>
            <span className="text-atbu-gold text-[10px] font-black uppercase tracking-[0.3em]">SECURE VAULT • {courseCode}</span>
          </div>
        </div>
        
        <div className="flex items-center space-x-3">
          <div className="px-4 py-2 bg-white/5 border border-white/10 rounded-xl flex items-center space-x-3">
            <Eye className="w-4 h-4 text-atbu-gold" />
            <span className="text-white font-bold text-xs">
              Page {currentPage} / {numPages || '--'}
            </span>
          </div>
          
          <div className="flex bg-white/5 p-1 rounded-xl border border-white/10">
            <button onClick={() => setScale(s => Math.max(0.5, s - 0.2))} className="p-2 text-white/40 hover:text-white transition-colors"><Settings className="w-4 h-4" /></button>
            <div className="w-px h-4 bg-white/10 self-center" />
            <button onClick={() => setScale(s => Math.min(2.0, s + 0.2))} className="p-2 text-white/40 hover:text-white transition-colors"><Maximize2 className="w-4 h-4" /></button>
          </div>
        </div>
      </div>

      {/* Reader Content */}
      <div className="flex-grow flex items-start justify-center p-4 md:p-12 overflow-auto scrollbar-hide bg-[#050810] relative">
        {/* Anti-Scrape Background Pattern */}
        <div className="absolute inset-0 opacity-[0.03] pointer-events-none" 
             style={{ backgroundImage: 'radial-gradient(#d4af37 1px, transparent 0)', backgroundSize: '40px 40px' }} />

        <AnimatePresence mode="wait">
          {loading ? (
            <motion.div 
              key="loading"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center justify-center space-y-6 mt-20"
            >
              <div className="relative">
                <div className="w-24 h-24 border-2 border-atbu-gold/20 rounded-full border-t-atbu-gold animate-spin" />
                <Lock className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-atbu-gold w-8 h-8" />
              </div>
              <p className="text-atbu-gold font-black uppercase tracking-[0.4em] text-[10px] animate-pulse">Establishing Secure Connection...</p>
            </motion.div>
          ) : error ? (
            <motion.div 
              key="error"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="max-w-md text-center p-12 glass-card border-crimson/20 mt-20"
            >
              <AlertCircle className="w-16 h-16 text-crimson mx-auto mb-6" />
              <h2 className="text-white font-black uppercase tracking-tighter text-xl mb-4">Security Protocol Exception</h2>
              <p className="text-white/40 text-sm font-medium leading-relaxed mb-8">{error}</p>
              <button onClick={onExit} className="bg-crimson text-white px-8 py-3 rounded-xl font-black uppercase tracking-widest text-xs">Back to Safety</button>
            </motion.div>
          ) : (
            <motion.div 
              key="document"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="relative group transition-all duration-700"
            >
              <Document
                file={fileUrl || "https://pdfobject.com/pdf/sample.pdf"} // Fallback to a sample if URL missing
                onLoadSuccess={onDocumentLoadSuccess}
                onLoadError={onDocumentLoadError}
                loading={null}
              >
                <div className="relative overflow-hidden rounded-[2px]">
                  <Page 
                    pageNumber={currentPage} 
                    scale={scale}
                    renderTextLayer={false}
                    renderAnnotationLayer={false}
                  />
                  
                  {/* Watermark Overlay */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none z-20">
                    <div className="grid grid-cols-3 grid-rows-4 gap-20 opacity-[0.08] -rotate-45 scale-150">
                      {Array.from({ length: 12 }).map((_, i) => (
                        <div key={i} className="text-atbu-gold font-black text-6xl whitespace-nowrap tracking-[0.5em] uppercase">
                          ATBU HUB
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Anti-Screenshot Overlay (Subtle Gradient) */}
                  <div className="absolute inset-0 bg-gradient-to-tr from-atbu-gold/5 via-transparent to-atbu-gold/5 pointer-events-none" />
                </div>
              </Document>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Footer Controls */}
      <div className="bg-[#0A0F1E] p-4 flex items-center justify-center space-x-12 border-t border-atbu-gold/10 relative z-10">
        <button 
          disabled={currentPage === 1}
          onClick={() => handlePageChange(currentPage - 1)}
          className="flex items-center space-x-3 text-white/40 font-black uppercase tracking-widest text-[10px] hover:text-atbu-gold transition-all disabled:opacity-20 translate-x-0 active:-translate-x-2"
        >
          <ChevronLeft className="w-5 h-5" />
          <span className="hidden md:inline">Shift Prev</span>
        </button>

        <div className="flex items-center space-x-4 bg-white/5 border border-white/10 px-8 py-3 rounded-2xl">
          <input 
            type="number"
            min={1}
            max={numPages || 1}
            value={currentPage}
            onChange={(e) => handlePageChange(parseInt(e.target.value) || 1)}
            className="bg-transparent text-atbu-gold font-black w-8 text-center outline-none"
          />
          <div className="w-px h-4 bg-white/10" />
          <span className="text-white/20 font-black text-xs uppercase tracking-widest">{numPages || '--'}</span>
        </div>

        <button 
          disabled={numPages ? currentPage === numPages : true}
          onClick={() => handlePageChange(currentPage + 1)}
          className="flex items-center space-x-3 text-white/40 font-black uppercase tracking-widest text-[10px] hover:text-atbu-gold transition-all disabled:opacity-20 translate-x-0 active:translate-x-2"
        >
          <span className="hidden md:inline">Shift Next</span>
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>

      {/* Security Status */}
      <div className="fixed bottom-6 right-6 z-[110] flex items-center space-x-2 text-[8px] font-black uppercase tracking-[0.4em] text-atbu-gold/40">
        <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
        <span>End-to-End Encrypted Session</span>
      </div>
    </div>
  );
};
