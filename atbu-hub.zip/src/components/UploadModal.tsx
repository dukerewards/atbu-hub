import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Upload, FileText, BookOpen, Newspaper, Send, CheckCircle2, ChevronRight, Loader2 } from 'lucide-react';
import { collection, addDoc, serverTimestamp, doc, updateDoc, increment } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';
import { cn } from '../lib/utils';
import { StorageService } from '../services/storageService';

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type ContentType = 'handout' | 'past_question' | 'news';

export const UploadModal: React.FC<UploadModalProps> = ({ isOpen, onClose }) => {
  const { user, profile } = useAuth();
  const [step, setStep] = useState(1);
  const [type, setType] = useState<ContentType | null>(null);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [file, setFile] = useState<File | null>(null);

  // Form states
  const [formData, setFormData] = useState({
    courseName: '',
    courseCode: '',
    part: '',
    year: '',
    examType: 'exam',
    headline: '',
    description: '',
  });

  const categories = [
    { id: 'handout', title: 'Handout', icon: <FileText className="w-6 h-6" />, desc: 'Lecture notes & summaries', color: 'bg-blue-500' },
    { id: 'past_question', title: 'Past Question', icon: <BookOpen className="w-6 h-6" />, desc: 'Exam & test papers', color: 'bg-emerald-500' },
    { id: 'news', title: 'Campus News', icon: <Newspaper className="w-6 h-6" />, desc: 'Events & announcements', color: 'bg-amber-500' },
  ];

  const handleTypeSelect = (id: ContentType) => {
    setType(id);
    setStep(2);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !type) return;

    setLoading(true);
    try {
      let fileUrl = '';
      let storageProvider: 'firebase' | 'drive' = 'firebase';

      if (file) {
        const path = `content/${type}/${Date.now()}_${file.name}`;
        const result = await StorageService.uploadFile(file, path);
        fileUrl = result.url;
        storageProvider = result.provider;
      }

      const payload = {
        type,
        ...formData,
        fileUrl,
        storageProvider,
        status: 'pending',
        title: type === 'news' ? formData.headline : formData.courseName || formData.courseCode,
        uploadedBy: user.uid,
        uploaderName: profile?.fullName || user.displayName || 'Scholar',
        createdAt: serverTimestamp(),
        tags: [formData.courseCode, type].filter(Boolean).map(t => t.toUpperCase()),
      };

      await addDoc(collection(db, 'campusContent'), payload);
      
      // Update reputation points for contributing
      await updateDoc(doc(db, 'users', user.uid), {
        reputationPoints: increment(10)
      });

      setSuccess(true);
      setTimeout(() => {
        onClose();
        resetForm();
      }, 2000);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'campusContent');
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setStep(1);
    setType(null);
    setSuccess(false);
    setFormData({
      courseName: '',
      courseCode: '',
      part: '',
      year: '',
      examType: 'exam',
      headline: '',
      description: '',
      fileUrl: ''
    });
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-atbu-navy/80 backdrop-blur-xl"
          />
          
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="relative w-full max-w-2xl bg-white dark:bg-atbu-navy border border-slate-200 dark:border-white/10 rounded-[40px] shadow-2xl overflow-hidden"
          >
            {/* Header */}
            <div className="p-8 border-b border-slate-100 dark:border-white/5 flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-black text-slate-900 dark:text-white tracing-tight">
                  {step === 1 ? 'Share Your Knowledge' : `Upload ${type?.replace('_', ' ')}`}
                </h2>
                <p className="text-slate-500 dark:text-white/40 text-sm">Contribute to the ATBU Hub ecosystem.</p>
              </div>
              <button 
                onClick={onClose}
                className="p-3 rounded-2xl bg-slate-100 dark:bg-white/5 text-slate-400 hover:text-slate-900 dark:hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-8">
              {success ? (
                <div className="py-12 text-center">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="w-20 h-20 bg-emerald-500 rounded-full flex items-center justify-center mx-auto mb-6 text-white"
                  >
                    <CheckCircle2 className="w-10 h-10" />
                  </motion.div>
                  <h3 className="text-2xl font-black text-slate-800 dark:text-white">Successfully Uploaded!</h3>
                  <p className="text-slate-500 dark:text-white/40 mt-2">Your contribution is now helping fellow students.</p>
                </div>
              ) : step === 1 ? (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {categories.map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => handleTypeSelect(cat.id as ContentType)}
                      className="group relative p-6 rounded-[32px] bg-slate-50 dark:bg-white/5 border-2 border-transparent hover:border-atbu-gold hover:bg-white dark:hover:bg-white/10 transition-all text-left overflow-hidden"
                    >
                      <div className={cn("w-12 h-12 rounded-2xl flex items-center justify-center mb-4 transition-transform group-hover:scale-110 group-hover:rotate-3", cat.color, "text-white")}>
                        {cat.icon}
                      </div>
                      <h3 className="font-black text-slate-900 dark:text-white uppercase tracking-wider text-sm">{cat.title}</h3>
                      <p className="text-xs text-slate-500 dark:text-white/40 mt-1">{cat.desc}</p>
                      <div className="absolute bottom-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
                        <ChevronRight className="w-5 h-5 text-atbu-gold" />
                      </div>
                    </button>
                  ))}
                </div>
              ) : (
                <form onSubmit={handleUpload} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {type === 'handout' && (
                      <>
                        <div className="space-y-2">
                          <label className="text-xs font-black uppercase tracking-widest text-slate-400">Course Name</label>
                          <input
                            required
                            type="text"
                            placeholder="e.g. Calculus II"
                            className="w-full px-5 py-4 bg-slate-50 dark:bg-white/5 rounded-2xl border-2 border-transparent focus:border-atbu-gold outline-none transition-all dark:text-white"
                            value={formData.courseName}
                            onChange={e => setFormData({...formData, courseName: e.target.value})}
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-xs font-black uppercase tracking-widest text-slate-400">Course Code</label>
                          <input
                            required
                            type="text"
                            placeholder="e.g. MTH 202"
                            className="w-full px-5 py-4 bg-slate-50 dark:bg-white/5 rounded-2xl border-2 border-transparent focus:border-atbu-gold outline-none transition-all dark:text-white"
                            value={formData.courseCode}
                            onChange={e => setFormData({...formData, courseCode: e.target.value})}
                          />
                        </div>
                        <div className="space-y-2 md:col-span-2">
                          <label className="text-xs font-black uppercase tracking-widest text-slate-400">Part/Session</label>
                          <input
                            required
                            type="text"
                            placeholder="e.g. Part 1, 2023/2024"
                            className="w-full px-5 py-4 bg-slate-50 dark:bg-white/5 rounded-2xl border-2 border-transparent focus:border-atbu-gold outline-none transition-all dark:text-white"
                            value={formData.part}
                            onChange={e => setFormData({...formData, part: e.target.value})}
                          />
                        </div>
                      </>
                    )}

                    {type === 'past_question' && (
                      <>
                        <div className="space-y-2">
                          <label className="text-xs font-black uppercase tracking-widest text-slate-400">Course Code</label>
                          <input
                            required
                            type="text"
                            placeholder="e.g. PHY 101"
                            className="w-full px-5 py-4 bg-slate-50 dark:bg-white/5 rounded-2xl border-2 border-transparent focus:border-atbu-gold outline-none transition-all dark:text-white"
                            value={formData.courseCode}
                            onChange={e => setFormData({...formData, courseCode: e.target.value})}
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-xs font-black uppercase tracking-widest text-slate-400">Year</label>
                          <input
                            required
                            type="text"
                            placeholder="e.g. 2023"
                            className="w-full px-5 py-4 bg-slate-50 dark:bg-white/5 rounded-2xl border-2 border-transparent focus:border-atbu-gold outline-none transition-all dark:text-white"
                            value={formData.year}
                            onChange={e => setFormData({...formData, year: e.target.value})}
                          />
                        </div>
                        <div className="space-y-2 md:col-span-2">
                          <label className="text-xs font-black uppercase tracking-widest text-slate-400">Type</label>
                          <div className="grid grid-cols-2 gap-4">
                            {['test', 'exam'].map((t) => (
                              <button
                                key={t}
                                type="button"
                                onClick={() => setFormData({...formData, examType: t})}
                                className={cn(
                                  "py-4 rounded-2xl border-2 font-black uppercase tracking-widest text-xs transition-all",
                                  formData.examType === t 
                                    ? "bg-atbu-gold border-atbu-gold text-atbu-navy" 
                                    : "border-slate-100 dark:border-white/5 text-slate-400 hover:border-atbu-gold"
                                )}
                              >
                                {t}
                              </button>
                            ))}
                          </div>
                        </div>
                      </>
                    )}

                    {type === 'news' && (
                      <>
                        <div className="space-y-2 md:col-span-2">
                          <label className="text-xs font-black uppercase tracking-widest text-slate-400">Headline</label>
                          <input
                            required
                            type="text"
                            placeholder="e.g. SRC General Meeting Update"
                            className="w-full px-5 py-4 bg-slate-50 dark:bg-white/5 rounded-2xl border-2 border-transparent focus:border-atbu-gold outline-none transition-all dark:text-white"
                            value={formData.headline}
                            onChange={e => setFormData({...formData, headline: e.target.value})}
                          />
                        </div>
                        <div className="space-y-2 md:col-span-2">
                          <label className="text-xs font-black uppercase tracking-widest text-slate-400">Description</label>
                          <textarea
                            required
                            rows={4}
                            placeholder="Provide details about the news..."
                            className="w-full px-5 py-4 bg-slate-50 dark:bg-white/5 rounded-2xl border-2 border-transparent focus:border-atbu-gold outline-none transition-all dark:text-white resize-none"
                            value={formData.description}
                            onChange={e => setFormData({...formData, description: e.target.value})}
                          />
                        </div>
                      </>
                    )}

                    <div className="space-y-2 md:col-span-2">
                      <label className="text-xs font-black uppercase tracking-widest text-slate-400">Select File/Resource</label>
                      <div className="relative group/file">
                        <input
                          required
                          type="file"
                          id="file-upload"
                          className="hidden"
                          onChange={handleFileChange}
                          accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                        />
                        <label 
                          htmlFor="file-upload"
                          className={cn(
                            "w-full flex flex-col items-center justify-center p-10 border-2 border-dashed rounded-[30px] cursor-pointer transition-all",
                            file 
                              ? "border-emerald-500 bg-emerald-500/5 text-emerald-500" 
                              : "border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-white/5 text-slate-400 hover:border-atbu-gold hover:text-atbu-gold"
                          )}
                        >
                          {file ? (
                            <>
                              <CheckCircle2 className="w-10 h-10 mb-2" />
                              <span className="font-black text-sm uppercase tracking-widest">{file.name}</span>
                              <span className="text-[10px] opacity-60">{(file.size / (1024 * 1024)).toFixed(2)} MB • Ready to sync</span>
                            </>
                          ) : (
                            <>
                              <Upload className="w-10 h-10 mb-2 opacity-20" />
                              <span className="font-black text-sm uppercase tracking-widest">Drop file or Browse</span>
                              <span className="text-[10px] opacity-60 mt-1 uppercase tracking-widest">PDF, Image or Document up to 20MB</span>
                            </>
                          )}
                        </label>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-4 pt-4">
                    <button
                      type="button"
                      onClick={() => setStep(1)}
                      className="px-8 py-4 rounded-2xl text-slate-500 font-bold hover:bg-slate-100 dark:hover:bg-white/5 transition-all"
                    >
                      Back
                    </button>
                    <button
                      disabled={loading}
                      type="submit"
                      className="flex-1 bg-atbu-navy dark:bg-atbu-gold text-atbu-gold dark:text-atbu-navy py-4 rounded-2xl font-black uppercase tracking-[0.2em] text-xs shadow-xl shadow-atbu-gold/10 hover:scale-[1.02] active:scale-95 transition-all disabled:opacity-50 flex items-center justify-center space-x-2"
                    >
                      {loading ? (
                        <Loader2 className="w-5 h-5 animate-spin" />
                      ) : (
                        <>
                          <Send className="w-5 h-5" />
                          <span>Publish Now</span>
                        </>
                      )}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
