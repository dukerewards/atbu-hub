import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { signInWithGoogle, logout } from '../lib/firebase';
import { Book, ShoppingBag, UserCircle, LogOut, LogIn, Menu, X, Star, Award, GraduationCap, Sun, Moon, MessageCircle, Plus, Shield } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';
import { UploadModal } from './UploadModal';

export const Navbar = () => {
  const { user, profile } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const location = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isUploadOpen, setIsUploadOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Library', path: '/library', icon: <Book className="w-5 h-5" /> },
    { name: 'Chat Space', path: '/chat', icon: <MessageCircle className="w-5 h-5" /> },
    { name: 'Practice', path: '/quizzes', icon: <Award className="w-5 h-5" /> },
    { name: 'About', path: '/about', icon: <Shield className="w-5 h-5" /> },
    { name: 'Market', path: '/market', icon: <ShoppingBag className="w-5 h-5" /> },
    { name: 'Elite', path: '/leaderboard', icon: <Star className="w-5 h-5" /> },
  ];

  return (
    <nav className={cn(
      "fixed top-0 left-0 w-full z-50 transition-all duration-500",
      isScrolled ? "py-4" : "py-8"
    )}>
      <div className="container mx-auto px-4 max-w-7xl">
        <div className={cn(
          "glass-card transition-all duration-500 flex items-center justify-between px-8 h-20 shadow-2xl",
          isScrolled ? "border-white/10" : "border-atbu-gold/10"
        )}>
          <Link to="/" className="flex items-center space-x-3 group">
            <div className="w-16 h-16 bg-atbu-gold rounded-2xl flex items-center justify-center shadow-lg shadow-atbu-gold/20 transform group-hover:rotate-12 transition-transform overflow-hidden p-0.5 glow-gold">
              <img 
                src="https://drive.google.com/uc?export=view&id=1_oU9oMI88OxBqNHN3zmXO5TpdOufRJlV"
                alt="ATBU Logo" 
                referrerPolicy="no-referrer"
                className="w-full h-full object-contain bg-white rounded-xl"
              />
            </div>
            <div className="hidden sm:block">
              <span className="text-white text-xl font-black tracking-tighter block leading-none">ATBU<span className="text-atbu-gold">HUB</span></span>
              <span className="text-[10px] text-atbu-gold font-black uppercase tracking-[0.3em]">Elite Portal</span>
            </div>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center space-x-1">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={cn(
                  "px-6 py-2.5 rounded-2xl text-sm font-black transition-all flex items-center space-x-2",
                  location.pathname === link.path
                    ? "bg-atbu-gold text-atbu-navy shadow-lg shadow-atbu-gold/20"
                    : "text-white/60 hover:text-white hover:bg-white/5"
                )}
              >
                {link.icon}
                <span className="uppercase tracking-widest">{link.name}</span>
              </Link>
            ))}
          </div>

          <div className="flex items-center space-x-4">
            {user && (
              <button
                onClick={() => setIsUploadOpen(true)}
                title="Upload Document"
                className="flex items-center space-x-2 bg-atbu-gold/10 text-atbu-gold px-3 py-2.5 md:px-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-atbu-gold hover:text-atbu-navy transition-all shadow-lg shadow-atbu-gold/5"
              >
                <Plus className="w-4 h-4" />
                <span className="hidden sm:inline">Upload</span>
              </button>
            )}

            {user ? (
              <div className="flex items-center space-x-4">
                <div className="hidden md:flex flex-col items-end mr-2">
                  <span className="text-white text-xs font-bold leading-none">{profile?.fullName || profile?.displayName}</span>
                  <span className="text-atbu-gold text-[10px] font-black uppercase tracking-widest leading-loose">{profile?.reputationPoints} PTS</span>
                </div>
                <Link to="/profile" className="relative group">
                  <img
                    src={user.photoURL || ''}
                    alt="Profile"
                    className="w-12 h-12 rounded-2xl border-2 border-atbu-gold/20 group-hover:border-atbu-gold transition-colors"
                  />
                  <div className="absolute -top-1 -right-1 w-4 h-4 bg-atbu-gold rounded-full border-2 border-[#0A0F1E] shadow-sm" />
                </Link>
                <button
                  onClick={() => logout()}
                  className="p-3 text-white/40 hover:text-white hover:bg-white/5 rounded-2xl transition-colors md:block hidden"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => signInWithGoogle()}
                className="bg-white text-atbu-navy px-8 py-3 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-atbu-gold hover:text-atbu-navy transition-all shadow-xl shadow-atbu-gold/5 active:scale-95"
              >
                Sign In
              </button>
            )}

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden p-3 bg-white/5 text-white rounded-2xl border border-white/10"
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="md:hidden mt-4 mx-4 bg-white dark:bg-atbu-navy/95 backdrop-blur-2xl border border-slate-200 dark:border-white/10 rounded-[40px] p-8 shadow-2xl"
          >
            <div className="flex flex-col space-y-4">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  onClick={() => setIsMenuOpen(false)}
                  className={cn(
                    "flex items-center space-x-4 p-5 rounded-3xl font-black uppercase tracking-widest text-sm",
                    location.pathname === link.path
                      ? "bg-atbu-gold text-atbu-navy"
                      : "text-slate-900 dark:text-white hover:bg-slate-100 dark:hover:bg-white/5"
                  )}
                >
                  {link.icon}
                  <span>{link.name}</span>
                </Link>
              ))}
              {user && (
                <button
                  onClick={() => {
                    setIsUploadOpen(true);
                    setIsMenuOpen(false);
                  }}
                  className="flex items-center space-x-4 p-5 rounded-3xl font-black uppercase tracking-widest text-sm bg-atbu-gold text-atbu-navy"
                >
                  <Plus className="w-5 h-5" />
                  <span>Upload Document</span>
                </button>
              )}
              {user && (
                <button
                  onClick={() => {
                    logout();
                    setIsMenuOpen(false);
                  }}
                  className="flex items-center space-x-4 p-5 rounded-3xl font-black uppercase tracking-widest text-sm text-red-500 hover:bg-white/5"
                >
                  <LogOut className="w-5 h-5" />
                  <span>Logout</span>
                </button>
              )}
              <button
                onClick={() => {
                  toggleTheme();
                  setIsMenuOpen(false);
                }}
                className="flex items-center space-x-4 p-5 rounded-3xl font-black uppercase tracking-widest text-sm text-slate-900 dark:text-white hover:bg-slate-100 dark:hover:bg-white/5"
              >
                {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
                <span>{theme === 'dark' ? 'Light Mode' : 'Dark Mode'}</span>
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      <UploadModal isOpen={isUploadOpen} onClose={() => setIsUploadOpen(false)} />
    </nav>
  );
};
