import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Bell, ExternalLink } from 'lucide-react';
import { AD_CONFIG } from '../services/adConfig';

interface AdState {
  isVignetteActive: boolean;
  canTriggerPopunder: boolean;
  lastVignetteTime: number;
  lastPopunderTime: number;
}

export const AdManager = () => {
  const [vignetteVisible, setVignetteVisible] = useState(false);
  const [pushVisible, setPushVisible] = useState(false);
  const [bannerVisible, setBannerVisible] = useState(true);
  const [lastVignette, setLastVignette] = useState(Date.now());
  const [lastPush, setLastPush] = useState(Date.now());
  const [lastPopunder, setLastPopunder] = useState(0);

  // Vignette Logic: Every 3 minutes
  useEffect(() => {
    const timer = setInterval(() => {
      const now = Date.now();
      if (now - lastVignette >= AD_CONFIG.VIGNETTE_INTERVAL * 1000) {
        setVignetteVisible(true);
        setLastVignette(now);
      }
    }, 10000); // Check every 10 seconds

    return () => clearInterval(timer);
  }, [lastVignette]);

  // In-Page Push Logic: Every 1 minute
  useEffect(() => {
    const timer = setInterval(() => {
      const now = Date.now();
      if (!vignetteVisible && now - lastPush >= AD_CONFIG.PUSH_INTERVAL * 1000) {
        setPushVisible(true);
        setLastPush(now);
        
        // Auto hide after 10 seconds
        setTimeout(() => setPushVisible(false), 10000);
      }
    }, 5000);

    return () => clearInterval(timer);
  }, [lastPush, vignetteVisible]);

  // Conflict Rule: Hide banner/push if Vignette is on screen
  useEffect(() => {
    if (vignetteVisible) {
      setPushVisible(false);
      setBannerVisible(false);
    } else {
      setBannerVisible(true);
    }
  }, [vignetteVisible]);

  // Popunder Logic: Handle clicks globally
  const handleGlobalClick = useCallback(() => {
    const now = Date.now();
    if (now - lastPopunder >= AD_CONFIG.POPUNDER_COOLDOWN * 1000) {
      console.log('Triggering Popunder:', AD_CONFIG.POPUNDER_ID);
      // In a real scenario, this would call the Monetag SDK's popunder trigger
      setLastPopunder(now);
    }
  }, [lastPopunder]);

  useEffect(() => {
    window.addEventListener('click', handleGlobalClick);
    return () => window.removeEventListener('click', handleGlobalClick);
  }, [handleGlobalClick]);

  return (
    <>
      {/* Vignette Ad */}
      <AnimatePresence>
        {vignetteVisible && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[9999] bg-black/95 flex flex-col items-center justify-center p-4"
          >
            <button 
              onClick={() => setVignetteVisible(false)}
              className="absolute top-8 right-8 text-white/40 hover:text-white p-2 hover:bg-white/10 rounded-full transition-all"
            >
              <X className="w-8 h-8" />
            </button>
            <div className="w-full max-w-4xl aspect-video bg-white/5 rounded-3xl border border-white/10 flex flex-col items-center justify-center space-y-6 overflow-hidden relative">
              <div className="absolute top-4 left-4 flex items-center space-x-2 px-3 py-1 bg-white/5 rounded-full">
                <div className="w-2 h-2 bg-atbu-gold rounded-full animate-pulse" />
                <span className="text-[10px] text-white/40 font-black uppercase tracking-widest">Sponsored Elite Content</span>
              </div>
              <div className="text-center space-y-4 px-8">
                <span className="text-atbu-gold text-xs font-black uppercase tracking-[0.4em]">Premium Feature Unleashed</span>
                <h2 className="text-4xl md:text-6xl font-black text-white tracking-tighter uppercase leading-none">
                  Exclusive <span className="text-atbu-gold">Academic</span> <br /> Resource Portal
                </h2>
                <p className="text-white/40 font-medium max-w-md mx-auto">
                  Access the highest resolution study materials and exam blueprints available.
                </p>
                <button className="bg-atbu-gold text-atbu-navy px-10 py-5 rounded-2xl font-black uppercase tracking-widest text-sm hover:scale-105 active:scale-95 transition-all shadow-2xl shadow-atbu-gold/20 flex items-center space-x-3 mx-auto">
                  <span>Upgrade to Elite</span>
                  <ExternalLink className="w-5 h-5" />
                </button>
              </div>
              {/* Asset Simulation */}
              <div className="absolute bottom-0 inset-x-0 h-1/3 bg-gradient-to-t from-atbu-gold/10 to-transparent opacity-50" />
            </div>
            <p className="mt-8 text-white/20 text-[10px] font-black uppercase tracking-[0.5em]">Advancing ATBU Excellence</p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* In-Page Push */}
      <AnimatePresence>
        {pushVisible && (
          <motion.div
            initial={{ x: 400, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: 400, opacity: 0 }}
            className="fixed top-24 right-4 z-[999] w-80"
          >
            <div className="glass-card p-4 flex items-start space-x-4 border-atbu-gold/40 shadow-2xl shadow-atbu-gold/5 relative overflow-hidden">
              <div className="absolute top-0 left-0 w-1 h-full bg-atbu-gold" />
              <div className="w-10 h-10 rounded-xl bg-atbu-gold/20 flex items-center justify-center shrink-0">
                <Bell className="w-5 h-5 text-atbu-gold" />
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="text-white font-black text-xs uppercase tracking-tighter mb-1">New Study Resource</h4>
                <p className="text-white/40 text-[10px] leading-snug line-clamp-2">A verified handout for MTH 202 was just uploaded by a top-rated student.</p>
              </div>
              <button 
                onClick={() => setPushVisible(false)}
                className="text-white/20 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Sticky Banner (Bottom) */}
      <AnimatePresence>
        {bannerVisible && (
          <motion.div
            initial={{ y: 100 }}
            animate={{ y: 0 }}
            exit={{ y: 100 }}
            className="fixed bottom-0 inset-x-0 z-[998] h-14 bg-atbu-navy/80 backdrop-blur-xl border-t border-white/10 flex items-center justify-center"
          >
            <div className="max-w-7xl w-full px-4 flex items-center justify-between">
              <div className="flex items-center space-x-3 text-[10px] font-black uppercase tracking-widest text-white/40">
                <span className="text-atbu-gold px-2 py-0.5 bg-atbu-gold/10 rounded">AD</span>
                <span>Exclusive Student Marketplace Offers</span>
              </div>
              <button className="text-atbu-gold hover:text-white transition-colors">
                <ExternalLink className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
