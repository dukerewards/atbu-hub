import React, { useState, useEffect } from 'react';
import { collection, query, getDocs, doc, updateDoc, orderBy } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../../lib/firebase';
import { Shield, UserMinus, UserPlus, Search, Mail, Building2, User2 } from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../../lib/utils';

export const UserManagement = () => {
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const q = query(collection(db, 'users'), orderBy('createdAt', 'desc'));
      const snap = await getDocs(q);
      setUsers(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, 'users');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleToggleBan = async (user: any) => {
    const newStatus = !user.isBanned;
    if (!window.confirm(`Are you sure you want to ${newStatus ? 'BAN' : 'UNBAN'} this user?`)) return;
    try {
      await updateDoc(doc(db, 'users', user.id), { isBanned: newStatus });
      setUsers(prev => prev.map(u => u.id === user.id ? { ...u, isBanned: newStatus } : u));
    } catch (err) {
      console.error(err);
    }
  };

  const handlePromote = async (user: any) => {
    const nextRole = user.role === 'contributor' ? 'student' : 'contributor';
    try {
      await updateDoc(doc(db, 'users', user.id), { 
        role: nextRole, 
        isContributor: nextRole === 'contributor' 
      });
      setUsers(prev => prev.map(u => u.id === user.id ? { ...u, role: nextRole, isContributor: nextRole === 'contributor' } : u));
    } catch (err) {
      console.error(err);
    }
  };

  const filteredUsers = users.filter(u => 
    u.fullName?.toLowerCase().includes(searchTerm.toLowerCase()) || 
    u.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    u.displayName?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-3xl font-black uppercase tracking-tighter text-atbu-gold">Identity Registry</h2>
          <p className="text-atbu-gold/40 text-xs font-black uppercase tracking-widest">Manage student access and authorities</p>
        </div>
        
        <div className="relative w-full max-w-md">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-atbu-gold/40 w-5 h-5" />
          <input
            type="text"
            placeholder="Search by name, email or UID..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-[#0a0a0a] border-2 border-atbu-gold/10 rounded-2xl p-4 pl-12 text-white focus:border-atbu-gold outline-none font-bold"
          />
        </div>
      </div>

      {loading ? (
        <div className="h-64 flex items-center justify-center border-2 border-atbu-gold/5 rounded-[40px]">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-atbu-gold"></div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredUsers.map((user) => (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              key={user.id}
              className={cn(
                "bg-[#0a0a0a] border-2 p-6 rounded-[32px] flex items-center justify-between group transition-all",
                user.isBanned ? "border-red-500/20 opacity-60" : "border-atbu-gold/5 hover:border-atbu-gold/30"
              )}
            >
              <div className="flex items-center space-x-4">
                <div className="relative">
                  <img src={user.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.uid}`} alt="" className="w-16 h-16 rounded-2xl object-cover bg-atbu-gold/10" />
                  {user.role === 'admin' && (
                    <div className="absolute -top-2 -right-2 w-6 h-6 bg-atbu-gold rounded-full flex items-center justify-center border-2 border-atbu-navy">
                      <Shield className="w-3 h-3 text-atbu-navy" />
                    </div>
                  )}
                </div>
                <div>
                  <h3 className="font-black text-white uppercase tracking-tight">{user.fullName || user.displayName}</h3>
                  <div className="flex flex-col space-y-1 mt-1">
                    <span className="text-[10px] text-atbu-gold/40 font-black uppercase tracking-widest flex items-center">
                      <Mail className="w-3 h-3 mr-1" /> {user.email}
                    </span>
                    <span className="text-[10px] text-atbu-gold/40 font-black uppercase tracking-widest flex items-center">
                      <Building2 className="w-3 h-3 mr-1" /> {user.department || 'Undecided'} • {user.gender || 'Not Specified'}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2 mt-3">
                    <span className={cn(
                      "px-2 py-0.5 rounded-md text-[8px] font-black uppercase tracking-widest",
                      user.role === 'admin' ? "bg-atbu-gold text-atbu-navy" : 
                      user.role === 'contributor' ? "bg-blue-500 text-white" : "bg-white/10 text-white/40"
                    )}>
                      {user.role}
                    </span>
                    {user.isBanned && (
                      <span className="px-2 py-0.5 bg-red-500 text-white rounded-md text-[8px] font-black uppercase tracking-widest">
                        BANNED
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex flex-col space-y-2 opacity-0 group-hover:opacity-100 transition-opacity">
                {user.role !== 'admin' && (
                  <>
                    <button 
                      onClick={() => handlePromote(user)}
                      className={cn(
                        "p-3 rounded-xl transition-all",
                        user.role === 'contributor' ? "bg-white/10 text-white hover:bg-white/20" : "bg-blue-500/10 text-blue-500 hover:bg-blue-500 hover:text-white"
                      )}
                      title={user.role === 'contributor' ? "Demote" : "Promote to Contributor"}
                    >
                      <UserPlus className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={() => handleToggleBan(user)}
                      className={cn(
                        "p-3 rounded-xl transition-all",
                        user.isBanned ? "bg-emerald-500/10 text-emerald-500 hover:bg-emerald-500 hover:text-white" : "bg-red-500/10 text-red-500 hover:bg-red-500 hover:text-white"
                      )}
                      title={user.isBanned ? "Unban" : "Ban User"}
                    >
                      {user.isBanned ? <User2 className="w-4 h-4" /> : <UserMinus className="w-4 h-4" />}
                    </button>
                  </>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
};
