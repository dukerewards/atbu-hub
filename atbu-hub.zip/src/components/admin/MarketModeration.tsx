import React, { useState, useEffect } from 'react';
import { collection, query, getDocs, doc, deleteDoc, orderBy } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { ShoppingBag, AlertCircle, Trash2, UserX, ExternalLink, Flag } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../../lib/utils';

export const MarketModeration = () => {
  const [reports, setReports] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [marketItems, setMarketItems] = useState<any[]>([]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const reportsSnap = await getDocs(query(collection(db, 'scamReports'), orderBy('createdAt', 'desc')));
      const marketSnap = await getDocs(query(collection(db, 'marketItems'), orderBy('createdAt', 'desc')));
      
      setReports(reportsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      setMarketItems(marketSnap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    } catch (err) { console.error(err); }
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleDeleteItem = async (id: string) => {
    if (!window.confirm('Eradicate this listing from the market?')) return;
    try {
      await deleteDoc(doc(db, 'marketItems', id));
      setMarketItems(prev => prev.filter(i => i.id !== id));
    } catch (err) { console.error(err); }
  };

  const handleDismissReport = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'scamReports', id));
      setReports(prev => prev.filter(r => r.id !== id));
    } catch (err) { console.error(err); }
  };

  return (
    <div className="space-y-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-3xl font-black uppercase tracking-tighter text-atbu-gold">Commercial Security</h2>
          <p className="text-atbu-gold/40 text-xs font-black uppercase tracking-widest">Sanitize the student market and eliminate threats</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* Scam Reports - The Red Area */}
        <div className="space-y-6">
          <div className="flex items-center space-x-3 mb-4">
            <div className="w-10 h-10 bg-red-500/20 rounded-xl flex items-center justify-center text-red-500 animate-pulse">
              <AlertCircle className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-black uppercase tracking-tighter text-red-500 italic underline decoration-red-500/20 underline-offset-8">Critical Scam Reports</h3>
          </div>

          <div className="space-y-4">
            <AnimatePresence>
              {reports.length === 0 ? (
                <div className="p-12 text-center border-2 border-dashed border-white/5 rounded-[40px] bg-white/2">
                  <p className="text-white/20 font-black uppercase tracking-widest text-xs">No active threats detected.</p>
                </div>
              ) : (
                reports.map((report) => (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    key={report.id}
                    className="bg-[#1a0505] border-2 border-red-500/20 p-6 rounded-[32px] space-y-4"
                  >
                    <div className="flex justify-between items-start">
                      <div className="space-y-1">
                        <span className="text-[10px] font-black bg-red-500 text-white px-2 py-0.5 rounded-md uppercase tracking-widest">
                          {report.reason}
                        </span>
                        <p className="text-white font-black uppercase tracking-tight text-lg mt-2">{report.details}</p>
                      </div>
                      <button 
                        onClick={() => handleDismissReport(report.id)}
                        className="p-2 text-white/20 hover:text-white transition-colors"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                    
                    <div className="flex items-center justify-between pt-4 border-t border-red-500/10">
                      <div className="flex items-center space-x-2">
                        <UserX className="w-4 h-4 text-red-500" />
                        <span className="text-[10px] font-black text-red-500/60 uppercase tracking-widest">Target UID: {report.reportedUserId.slice(0, 12)}...</span>
                      </div>
                      <button className="text-[10px] font-black text-white uppercase tracking-widest hover:underline">Investigate Profile</button>
                    </div>
                  </motion.div>
                ))
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Global Market List */}
        <div className="space-y-6">
          <div className="flex items-center space-x-3 mb-4">
            <div className="w-10 h-10 bg-atbu-gold/10 rounded-xl flex items-center justify-center text-atbu-gold">
              <ShoppingBag className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-black uppercase tracking-tighter text-atbu-gold italic">Global Listing Cleanse</h3>
          </div>

          <div className="space-y-3 max-h-[600px] overflow-y-auto pr-4 scrollbar-hide">
            {marketItems.map((item) => (
              <div key={item.id} className="bg-[#0a0a0a] border border-white/5 p-4 rounded-2xl flex items-center justify-between group hover:border-atbu-gold/40 transition-all">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-white/5 rounded-xl overflow-hidden shrink-0">
                    {item.imageUrl && <img src={item.imageUrl} className="w-full h-full object-cover" />}
                  </div>
                  <div>
                    <h4 className="text-sm font-black text-white uppercase tracking-tight">{item.name}</h4>
                    <p className="text-[10px] font-black text-atbu-gold/40 uppercase tracking-widest italic">₦{item.price.toLocaleString()} • {item.sellerName}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <button className="p-2 text-white/20 hover:text-white transition-colors">
                    <ExternalLink className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={() => handleDeleteItem(item.id)}
                    className="p-2 text-red-500/20 hover:text-red-500 hover:bg-red-500/10 rounded-lg transition-all"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
