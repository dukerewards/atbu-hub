import React, { useState, useEffect } from 'react';
import { collection, query, where, getDocs, doc, updateDoc, deleteDoc, orderBy, serverTimestamp } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { Check, X, Edit2, ExternalLink, FileText, BookOpen, Clock } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../../lib/utils';

export const ApprovalQueue = () => {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingItem, setEditingItem] = useState<any>(null);

  const fetchQueue = async () => {
    setLoading(true);
    try {
      const q = query(
        collection(db, 'campusContent'),
        where('status', '==', 'pending'),
        orderBy('createdAt', 'desc')
      );
      const snap = await getDocs(q);
      setItems(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchQueue();
  }, []);

  const handleApprove = async (id: string) => {
    try {
      await updateDoc(doc(db, 'campusContent', id), {
        status: 'approved',
        approvedAt: serverTimestamp()
      });
      setItems(prev => prev.filter(i => i.id !== id));
    } catch (err) {
      console.error(err);
    }
  };

  const handleReject = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this resource?')) return;
    try {
      await deleteDoc(doc(db, 'campusContent', id));
      setItems(prev => prev.filter(i => i.id !== id));
    } catch (err) {
      console.error(err);
    }
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await updateDoc(doc(db, 'campusContent', editingItem.id), {
        courseCode: editingItem.courseCode.toUpperCase(),
        courseName: editingItem.courseName,
        title: editingItem.title
      });
      setItems(prev => prev.map(i => i.id === editingItem.id ? editingItem : i));
      setEditingItem(null);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-black uppercase tracking-tighter text-atbu-gold">Pending Approvals</h2>
          <p className="text-atbu-gold/40 text-xs font-black uppercase tracking-widest">Verify and publish student resources</p>
        </div>
        <div className="bg-atbu-gold/10 px-4 py-2 rounded-xl text-atbu-gold font-black text-xs uppercase tracking-widest border border-atbu-gold/20">
          {items.length} Items Waiting
        </div>
      </div>

      {loading ? (
        <div className="h-64 flex items-center justify-center border-2 border-atbu-gold/5 rounded-[40px]">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-atbu-gold"></div>
        </div>
      ) : items.length === 0 ? (
        <div className="h-64 flex flex-col items-center justify-center border-2 border-dashed border-atbu-gold/20 rounded-[40px] bg-atbu-gold/5">
          <Check className="w-12 h-12 text-atbu-gold/40 mb-4" />
          <p className="text-atbu-gold/40 font-black uppercase tracking-widest text-sm">All clear! No pending items.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6">
          {items.map((item) => (
            <motion.div
              layout
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              key={item.id}
              className="bg-[#0a0a0a] border border-atbu-gold/10 rounded-[32px] p-8 flex flex-col lg:flex-row lg:items-center justify-between gap-8 group hover:border-atbu-gold/40 transition-all"
            >
              <div className="flex items-start space-x-6">
                <div className={cn(
                  "w-16 h-16 rounded-[24px] flex items-center justify-center shrink-0",
                  item.type === 'handout' ? 'bg-blue-500/20 text-blue-500' : 'bg-emerald-500/20 text-emerald-500'
                )}>
                  {item.type === 'handout' ? <FileText className="w-8 h-8" /> : <BookOpen className="w-8 h-8" />}
                </div>
                <div className="space-y-2">
                  <div className="flex items-center space-x-3">
                    <span className="text-[10px] font-black bg-atbu-gold text-atbu-navy px-2 py-0.5 rounded-md uppercase tracking-widest">
                      {item.courseCode}
                    </span>
                    <span className="text-[10px] font-black text-atbu-gold/60 uppercase tracking-widest flex items-center">
                      <Clock className="w-3 h-3 mr-1" />
                      {item.createdAt?.toDate().toLocaleDateString()}
                    </span>
                  </div>
                  <h3 className="text-xl font-black text-white uppercase tracking-tight">{item.title || item.courseName}</h3>
                  <p className="text-xs text-atbu-gold/40 font-bold uppercase tracking-widest">
                    Uploaded by: <span className="text-atbu-gold">{item.uploaderName}</span> • {item.type}
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <a 
                  href={item.fileUrl} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="p-4 bg-white/5 text-white rounded-2xl hover:bg-white/10 transition-colors"
                >
                  <ExternalLink className="w-5 h-5" />
                </a>
                <button 
                  onClick={() => setEditingItem(item)}
                  className="p-4 bg-white/5 text-white rounded-2xl hover:bg-white/10 transition-colors"
                >
                  <Edit2 className="w-5 h-5" />
                </button>
                <button 
                  onClick={() => handleReject(item.id)}
                  className="p-4 bg-red-500/10 text-red-500 rounded-2xl hover:bg-red-500 hover:text-white transition-all"
                >
                  <X className="w-5 h-5" />
                </button>
                <button 
                  onClick={() => handleApprove(item.id)}
                  className="px-8 py-4 bg-atbu-gold text-atbu-navy rounded-2xl font-black uppercase tracking-widest text-xs hover:scale-105 transition-all shadow-xl shadow-atbu-gold/20"
                >
                  Approve
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {/* Edit Modal */}
      <AnimatePresence>
        {editingItem && (
          <div className="fixed inset-0 z-[150] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-[#0a0a0a] border border-atbu-gold/20 p-10 rounded-[40px] w-full max-w-xl shadow-2xl relative"
            >
              <button 
                onClick={() => setEditingItem(null)}
                className="absolute top-8 right-8 text-atbu-gold/40 hover:text-atbu-gold"
              >
                <X className="w-6 h-6" />
              </button>

              <h3 className="text-2xl font-black text-atbu-gold uppercase tracking-tighter mb-8 italic">Refine Resource</h3>
              
              <form onSubmit={handleSaveEdit} className="space-y-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-atbu-gold/60 uppercase tracking-widest ml-4">Course Code</label>
                  <input
                    type="text"
                    value={editingItem.courseCode}
                    onChange={(e) => setEditingItem({...editingItem, courseCode: e.target.value})}
                    className="w-full bg-white/5 border-2 border-atbu-gold/10 rounded-2xl p-4 text-white focus:border-atbu-gold outline-none uppercase font-bold"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-atbu-gold/60 uppercase tracking-widest ml-4">Full Title</label>
                  <input
                    type="text"
                    value={editingItem.title}
                    onChange={(e) => setEditingItem({...editingItem, title: e.target.value})}
                    className="w-full bg-white/5 border-2 border-atbu-gold/10 rounded-2xl p-4 text-white focus:border-atbu-gold outline-none font-bold"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-5 bg-atbu-gold text-atbu-navy rounded-2xl font-black uppercase tracking-widest text-sm hover:shadow-2xl shadow-atbu-gold/10 transition-all"
                >
                  Save Changes
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
