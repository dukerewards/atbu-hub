import React, { useState, useRef } from 'react';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { Newspaper, Send, Image as ImageIcon, X, Upload, Loader2, CheckCircle2 } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { StorageService } from '../../services/storageService';
import { cn } from '../../lib/utils';

export const NewsManager = () => {
  const { user } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [formData, setFormData] = useState({
    headline: '',
    description: '',
    imageUrl: ''
  });
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [uploadingImage, setUploadingImage] = useState(false);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      setFile(selectedFile);
      
      // Auto-upload and set URL
      setUploadingImage(true);
      try {
        const path = `news/${Date.now()}_${selectedFile.name}`;
        const result = await StorageService.uploadFile(selectedFile, path);
        setFormData(prev => ({ ...prev, imageUrl: result.url }));
      } catch (err) {
        console.error('Upload failed:', err);
        setFile(null);
      } finally {
        setUploadingImage(false);
      }
    }
  };

  const removeImage = () => {
    setFile(null);
    setFormData(prev => ({ ...prev, imageUrl: '' }));
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setLoading(true);

    try {
      await addDoc(collection(db, 'campusContent'), {
        ...formData,
        type: 'news',
        status: 'approved',
        source: 'official',
        author: 'Official Memo',
        uploadedBy: user.uid,
        uploaderName: user.displayName || 'Admin',
        createdAt: serverTimestamp(),
      });
      setFormData({ headline: '', description: '', imageUrl: '' });
      setFile(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
      alert('News published successfully');
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-3xl space-y-8">
      <div>
        <h2 className="text-3xl font-black uppercase tracking-tighter text-atbu-gold">Flash News Editor</h2>
        <p className="text-atbu-gold/40 text-xs font-black uppercase tracking-widest">Broadcast official memos to the student body</p>
      </div>

      <div className="bg-[#0a0a0a] border-2 border-atbu-gold/10 rounded-[40px] p-10">
        <form onSubmit={handleSubmit} className="space-y-8">
          <div className="space-y-2">
            <label className="text-[10px] font-black text-atbu-gold uppercase tracking-widest ml-4">Headline</label>
            <input
              required
              type="text"
              value={formData.headline}
              onChange={(e) => setFormData({...formData, headline: e.target.value})}
              className="w-full bg-white/5 border-2 border-atbu-gold/10 rounded-2xl p-4 text-white focus:border-atbu-gold outline-none font-bold placeholder:text-white/10"
              placeholder="e.g. SUSPENSION OF ACADEMIC ACTIVITIES"
            />
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black text-atbu-gold uppercase tracking-widest ml-4">Content Body</label>
            <textarea
              required
              rows={6}
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
              className="w-full bg-white/5 border-2 border-atbu-gold/10 rounded-2xl p-4 text-white focus:border-atbu-gold outline-none font-bold placeholder:text-white/10 resize-none"
              placeholder="Provide detailed information here..."
            />
          </div>

          <div className="space-y-4">
            <label className="text-[10px] font-black text-atbu-gold uppercase tracking-widest ml-4">Banner Media</label>
            
            {!formData.imageUrl && !uploadingImage ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="relative group">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileChange}
                    ref={fileInputRef}
                    className="hidden"
                    id="news-image-upload"
                  />
                  <label
                    htmlFor="news-image-upload"
                    className="flex flex-col items-center justify-center p-8 border-2 border-dashed border-atbu-gold/20 rounded-2xl bg-white/5 cursor-pointer hover:border-atbu-gold transition-all"
                  >
                    <Upload className="w-8 h-8 text-atbu-gold mb-2 opacity-50" />
                    <span className="text-[10px] font-black text-white uppercase tracking-widest">Upload Image</span>
                  </label>
                </div>
                
                <div className="relative">
                  <ImageIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-atbu-gold/40 w-5 h-5" />
                  <input
                    type="url"
                    value={formData.imageUrl}
                    onChange={(e) => setFormData({...formData, imageUrl: e.target.value})}
                    className="w-full h-full bg-white/5 border-2 border-atbu-gold/10 rounded-2xl p-4 pl-12 text-white focus:border-atbu-gold outline-none font-bold placeholder:text-white/10"
                    placeholder="...or paste URL"
                  />
                </div>
              </div>
            ) : (
              <div className="relative bg-white/5 border-2 border-atbu-gold/20 rounded-2xl p-4 flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  {uploadingImage ? (
                    <div className="w-12 h-12 bg-white/5 rounded-xl flex items-center justify-center">
                      <Loader2 className="w-6 h-6 text-atbu-gold animate-spin" />
                    </div>
                  ) : (
                    <div className="w-12 h-12 rounded-xl overflow-hidden border border-atbu-gold/20">
                      <img src={formData.imageUrl} alt="Preview" className="w-full h-full object-cover" />
                    </div>
                  )}
                  <div className="flex flex-col">
                    <span className="text-white text-xs font-bold leading-none">
                      {uploadingImage ? 'Syncing image to Cloud...' : (file?.name || 'Image Linked')}
                    </span>
                    <span className="text-atbu-gold text-[10px] uppercase font-black tracking-widest mt-1">
                      {uploadingImage ? 'Please wait' : 'Ready to Publish'}
                    </span>
                  </div>
                </div>
                {!uploadingImage && (
                  <button 
                    onClick={removeImage}
                    className="p-2 bg-red-500/10 text-red-500 rounded-lg hover:bg-red-500 hover:text-white transition-all"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
            )}
          </div>

          <button
            disabled={loading || uploadingImage}
            type="submit"
            className="w-full py-5 bg-atbu-gold text-atbu-navy rounded-2xl font-black uppercase tracking-widest text-sm hover:shadow-2xl shadow-atbu-gold/10 transition-all flex items-center justify-center space-x-3 disabled:opacity-50"
          >
            <Send className="w-5 h-5" />
            <span>{loading ? 'Transmitting...' : 'Dispatch Memo'}</span>
          </button>
        </form>
      </div>

      {formData.headline && (
        <div className="space-y-4">
          <h3 className="text-xl font-black text-atbu-gold uppercase tracking-tighter ml-4">Live Preview</h3>
          <div className="bg-white p-8 rounded-[40px] text-atbu-navy overflow-hidden">
            <div className="flex gap-2 mb-4">
              <span className="px-3 py-1 bg-atbu-gold text-atbu-navy rounded-full text-[8px] font-black uppercase tracking-widest">Official Notice</span>
            </div>
            {formData.imageUrl && (
              <div className="aspect-video w-full rounded-2xl overflow-hidden mb-6 border border-slate-100">
                <img src={formData.imageUrl} alt="Banner" className="w-full h-full object-cover" />
              </div>
            )}
            <h4 className="text-2xl font-black uppercase tracking-tighter mb-4 leading-tight">{formData.headline || 'Untitled Memo'}</h4>
            <div className="prose prose-sm max-w-none text-slate-600 line-clamp-6">
              {formData.description || 'Memo content will appear here...'}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
