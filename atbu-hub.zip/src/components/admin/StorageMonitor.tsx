import React, { useState, useEffect } from 'react';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { HardDrive, Cloud, AlertCircle, Database, RefreshCw, Key, ShieldCheck } from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../../lib/utils';

export const StorageMonitor = () => {
  const [config, setConfig] = useState({
    driveApiKey: '',
    driveFolderId: '',
    storageThresholdPercent: 80
  });
  const [isSyncing, setIsSyncing] = useState(false);
  const [loading, setLoading] = useState(true);

  // Mock usage data
  const firebaseUsage = 0.42; // 420MB used of 5GB
  const limit = 5; // 5GB limit for Spark plan
  const usedGB = firebaseUsage;
  const percent = (usedGB / limit) * 100;

  useEffect(() => {
    const fetchConfig = async () => {
      try {
        const snap = await getDoc(doc(db, 'adminConfigs', 'storage'));
        if (snap.exists()) setConfig(snap.data() as any);
      } catch (err) { console.error(err); }
      setLoading(false);
    };
    fetchConfig();
  }, []);

  const handleSaveConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSyncing(true);
    try {
      await setDoc(doc(db, 'adminConfigs', 'storage'), {
        ...config,
        updatedAt: new Date().toISOString()
      });
      alert('Vault configuration updated.');
    } catch (err) { console.error(err); }
    setIsSyncing(false);
  };

  const circularSize = 200;
  const strokeWidth = 12;
  const radius = (circularSize - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  const offset = circumference - (percent / 100) * circumference;

  return (
    <div className="space-y-12">
      <div>
        <h2 className="text-4xl font-black uppercase tracking-tighter text-atbu-gold italic">Storage Vault</h2>
        <p className="text-atbu-gold/40 text-xs font-black uppercase tracking-widest">Monitor Firebase capacity and Drive overflow protocol</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Firebase Storage Monitor - Circular Speedometer */}
        <div className="bg-[#0a0a0a] border-2 border-atbu-gold/10 rounded-[40px] p-10 flex flex-col items-center">
          <div className="flex items-center space-x-4 mb-8 w-full">
            <div className="w-12 h-12 bg-atbu-gold/10 rounded-2xl flex items-center justify-center text-atbu-gold">
              <Database className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-black uppercase tracking-tight text-white">Firebase Peak</h3>
              <p className="text-[10px] font-black uppercase tracking-widest text-atbu-gold/40">Saturation Level</p>
            </div>
          </div>

          <div className="relative flex items-center justify-center mb-10">
            <svg width={circularSize} height={circularSize} className="transform -rotate-90">
              {/* Background Circle */}
              <circle
                cx={circularSize / 2}
                cy={circularSize / 2}
                r={radius}
                stroke="currentColor"
                strokeWidth={strokeWidth}
                fill="transparent"
                className="text-white/5"
              />
              {/* Progress Circle */}
              <motion.circle
                initial={{ strokeDashoffset: circumference }}
                animate={{ strokeDashoffset: offset }}
                transition={{ duration: 1, ease: "easeOut" }}
                cx={circularSize / 2}
                cy={circularSize / 2}
                r={radius}
                stroke="currentColor"
                strokeWidth={strokeWidth}
                strokeDasharray={circumference}
                fill="transparent"
                className={cn(
                  "transition-colors duration-500",
                  percent > 80 ? 'text-red-500' : 'text-atbu-gold'
                )}
                strokeLinecap="round"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
              <span className="text-4xl font-black text-white italic">{percent.toFixed(0)}%</span>
              <span className="text-[10px] font-black uppercase tracking-[0.2em] text-atbu-gold/40 mt-1">Capacity</span>
            </div>
          </div>

          <div className="w-full space-y-4">
            <div className="flex justify-between text-xs font-black uppercase tracking-widest">
              <span className="text-atbu-gold/40">Used: <span className="text-white">{usedGB.toFixed(2)}GB</span></span>
              <span className="text-atbu-gold/40">Limit: <span className="text-white">5.0Gb</span></span>
            </div>
            <div className={cn(
              "flex items-center p-4 rounded-2xl space-x-3 border",
              percent > 80 
                ? "bg-red-500/10 border-red-500/20 text-red-500" 
                : "bg-atbu-gold/5 border-atbu-gold/10 text-atbu-gold"
            )}>
              <AlertCircle className="w-5 h-5 shrink-0" />
              <p className="text-[10px] font-black uppercase tracking-wider">
                {percent > 80 
                  ? "Storage threshold critical. Migration protocol primed." 
                  : "All systems operating within nominal capacity."}
              </p>
            </div>
          </div>
        </div>

        {/* Google Drive Status */}
        <div className="bg-[#0a0a0a] border-2 border-atbu-gold/10 rounded-[40px] p-10 space-y-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-emerald-500/10 rounded-2xl flex items-center justify-center text-emerald-500">
                <Cloud className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-black uppercase tracking-tight text-white">Drive Backup</h3>
                <p className="text-[10px] font-black uppercase tracking-widest text-atbu-gold/40">Overflow Destination</p>
              </div>
            </div>
            <div className="px-4 py-2 bg-emerald-500/10 rounded-xl border border-emerald-500/20">
              <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest">Online</span>
            </div>
          </div>

          <div className="p-6 bg-white/5 rounded-3xl border border-white/5 space-y-4">
            <div className="flex items-center justify-between text-xs font-black uppercase tracking-widest text-atbu-gold/40">
              <span>Total Archived</span>
              <span className="text-white">124 Files</span>
            </div>
            <div className="flex items-center justify-between text-xs font-black uppercase tracking-widest text-atbu-gold/40">
              <span>Drive Bandwidth</span>
              <span className="text-white">Unlimited</span>
            </div>
            <div className="flex items-center justify-between text-xs font-black uppercase tracking-widest text-atbu-gold/40">
              <span>Auto-Sync Status</span>
              <span className="text-emerald-500">Live</span>
            </div>
          </div>
          
          <button className="w-full py-4 bg-white/5 text-atbu-gold border-2 border-atbu-gold/20 rounded-2xl font-black uppercase tracking-widest text-[10px] hover:bg-atbu-gold/10 transition-all flex items-center justify-center space-x-3">
            <RefreshCw className="w-4 h-4" />
            <span>Integrity Check</span>
          </button>
        </div>
      </div>

      {/* Settings Panel */}
      <div className="bg-[#0a0a0a] border-2 border-atbu-gold/10 rounded-[40px] overflow-hidden">
        <div className="p-8 border-b border-atbu-gold/10 flex items-center space-x-3">
          <Key className="w-6 h-6 text-atbu-gold" />
          <h3 className="text-xl font-black uppercase tracking-tight text-white italic">Protocol Configuration</h3>
        </div>
        
        <form onSubmit={handleSaveConfig} className="p-10 grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-2">
            <label className="text-[10px] font-black text-atbu-gold/40 uppercase tracking-widest ml-4">Google Drive API Key</label>
            <div className="relative">
              <ShieldCheck className="absolute left-4 top-1/2 -translate-y-1/2 text-atbu-gold/20 w-5 h-5" />
              <input
                type="password"
                value={config.driveApiKey}
                onChange={(e) => setConfig({...config, driveApiKey: e.target.value})}
                className="w-full bg-white/5 border-2 border-atbu-gold/10 rounded-2xl p-4 pl-12 text-white focus:border-atbu-gold outline-none font-mono text-sm"
                placeholder="AIzaSyA..."
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black text-atbu-gold/40 uppercase tracking-widest ml-4">Target Folder ID</label>
            <input
              type="text"
              value={config.driveFolderId}
              onChange={(e) => setConfig({...config, driveFolderId: e.target.value})}
              className="w-full bg-white/5 border-2 border-atbu-gold/10 rounded-2xl p-4 text-white focus:border-atbu-gold outline-none font-mono text-sm"
              placeholder="1A2B3C4D5E6F..."
            />
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black text-atbu-gold/40 uppercase tracking-widest ml-4">Overflow Threshold (%)</label>
            <input
              type="range"
              min="10"
              max="95"
              value={config.storageThresholdPercent}
              onChange={(e) => setConfig({...config, storageThresholdPercent: parseInt(e.target.value)})}
              className="w-full h-2 bg-white/10 rounded-lg appearance-none cursor-pointer accent-atbu-gold mt-4"
            />
            <div className="flex justify-between text-[10px] font-black uppercase tracking-widest text-atbu-gold mt-2">
              <span>Relaxed (10%)</span>
              <span>Value: {config.storageThresholdPercent}%</span>
              <span>Ultra (95%)</span>
            </div>
          </div>

          <div className="flex items-end">
            <button
              disabled={isSyncing}
              type="submit"
              className="w-full py-5 bg-atbu-gold text-atbu-navy rounded-2xl font-black uppercase tracking-widest text-sm hover:shadow-2xl shadow-atbu-gold/10 transition-all flex items-center justify-center space-x-3"
            >
              <HardDrive className="w-5 h-5" />
              <span>{isSyncing ? 'Locking Protocols...' : 'Commit Settings'}</span>
            </button>
          </div>
        </form>

        <div className="p-8 bg-atbu-gold/5 border-t border-atbu-gold/10">
          <div className="flex items-start space-x-4">
            <div className="p-2 bg-atbu-gold/10 rounded-lg">
              <AlertCircle className="w-5 h-5 text-atbu-gold" />
            </div>
            <div>
              <h4 className="text-xs font-black text-atbu-gold uppercase tracking-widest mb-1">Backup Logistics Guide</h4>
              <p className="text-[10px] text-atbu-gold/60 font-bold leading-relaxed max-w-2xl">
                To link your Google Drive: (1) Go to Google Cloud Console, (2) Create a Service Account or API Key, 
                (3) Enable the Google Drive API, (4) Share your Target Folder with the service account email or use the API Key below. 
                All files identified as "Oldest" (createdAt ASC) will be migrated to Drive once usage exceeds threshold.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
