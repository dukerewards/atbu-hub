import React from 'react';
import { motion } from 'motion/react';
import { Shield, Users, FileCheck, Newspaper, BarChart3, HardDrive, AlertTriangle, LogOut, Home } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { logout } from '../../lib/firebase';
import { cn } from '../../lib/utils';

export const AdminLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const location = useLocation();

  const navItems = [
    { name: 'Overview', path: '/duke-vault', icon: <BarChart3 className="w-5 h-5" /> },
    { name: 'Approvals', path: '/duke-vault/approvals', icon: <FileCheck className="w-5 h-5" /> },
    { name: 'Users', path: '/duke-vault/users', icon: <Users className="w-5 h-5" /> },
    { name: 'News', path: '/duke-vault/news', icon: <Newspaper className="w-5 h-5" /> },
    { name: 'Market Moderation', path: '/duke-vault/market', icon: <AlertTriangle className="w-5 h-5" /> },
    { name: 'Storage', path: '/duke-vault/storage', icon: <HardDrive className="w-5 h-5" /> },
  ];

  return (
    <div className="min-h-screen bg-[#050505] text-white flex">
      {/* Sidebar */}
      <aside className="w-80 border-r border-atbu-gold/20 flex flex-col shrink-0 bg-[#0a0a0a]">
        <div className="p-8 border-b border-atbu-gold/10">
          <div className="flex items-center space-x-3 mb-8">
            <div className="w-12 h-12 bg-atbu-gold rounded-2xl flex items-center justify-center shadow-2xl shadow-atbu-gold/20">
              <Shield className="w-7 h-7 text-atbu-navy" />
            </div>
            <div>
              <h1 className="text-xl font-black uppercase tracking-tighter text-atbu-gold">Duke Vault</h1>
              <p className="text-[10px] font-black uppercase tracking-widest text-atbu-gold/40">Admin Control Center</p>
            </div>
          </div>

          <nav className="space-y-2">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={cn(
                  "flex items-center space-x-3 px-4 py-3.5 rounded-2xl font-black text-xs uppercase tracking-widest transition-all group",
                  location.pathname === item.path
                    ? "bg-atbu-gold text-atbu-navy shadow-lg shadow-atbu-gold/10"
                    : "text-atbu-gold/40 hover:bg-atbu-gold/5 hover:text-atbu-gold"
                )}
              >
                <span className={cn(
                  "transition-transform duration-300 group-hover:scale-110",
                  location.pathname === item.path ? "text-atbu-navy" : "text-atbu-gold"
                )}>
                  {item.icon}
                </span>
                <span>{item.name}</span>
              </Link>
            ))}
          </nav>
        </div>

        <div className="mt-auto p-8 border-t border-atbu-gold/10 flex flex-col space-y-4">
          <Link
            to="/"
            className="flex items-center space-x-3 px-4 py-3 text-atbu-gold/60 hover:text-white transition-colors"
          >
            <Home className="w-5 h-5" />
            <span className="font-bold text-sm">Exit to Site</span>
          </Link>
          <button
            onClick={() => logout()}
            className="flex items-center space-x-3 px-4 py-3 text-red-500 hover:text-red-400 transition-colors"
          >
            <LogOut className="w-5 h-5" />
            <span className="font-bold text-sm">Terminate Session</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 h-screen overflow-y-auto bg-gradient-to-br from-[#050505] to-[#0f0f0f] p-12">
        <div className="max-w-6xl mx-auto">
          {children}
        </div>
      </main>
    </div>
  );
};
