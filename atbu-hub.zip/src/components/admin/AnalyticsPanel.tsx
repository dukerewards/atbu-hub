import React, { useState, useEffect } from 'react';
import { collection, query, getDocs, limit, orderBy } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { TrendingUp, Users, Search, Award, Activity, BarChart, PieChart } from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../../lib/utils';

export const AnalyticsPanel = () => {
  const [stats, setStats] = useState<any>({
    activeToday: 42,
    totalUsers: 156,
    trendingCourse: 'MTH 101',
    uploadCount: 89
  });

  const [recentLogins, setRecentLogins] = useState<any[]>([]);

  useEffect(() => {
    // Real-time sign-in counter would use siteStats, but here we estimate from users collection
    const fetchStats = async () => {
      try {
        const usersSnap = await getDocs(collection(db, 'users'));
        const contentSnap = await getDocs(collection(db, 'campusContent'));
        
        // Mocking some logic for demo
        setStats({
          activeToday: Math.floor(usersSnap.size * 0.3),
          totalUsers: usersSnap.size,
          trendingCourse: 'MTH 202', // This would normally come from search aggregation
          uploadCount: contentSnap.size
        });

        const q = query(collection(db, 'users'), orderBy('createdAt', 'desc'), limit(5));
        const snap = await getDocs(q);
        setRecentLogins(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      } catch (err) { console.error(err); }
    };
    fetchStats();
  }, []);

  const metrics = [
    { label: 'Active Spirits', value: stats.activeToday, icon: <Activity className="w-5 h-5" />, color: 'text-atbu-gold' },
    { label: 'Total Scholars', value: stats.totalUsers, icon: <Users className="w-5 h-5" />, color: 'text-blue-500' },
    { label: 'Vault Additions', value: stats.uploadCount, icon: <TrendingUp className="w-5 h-5" />, color: 'text-emerald-500' },
    { label: 'Top Query', value: stats.trendingCourse, icon: <Search className="w-5 h-5" />, color: 'text-purple-500' },
  ];

  return (
    <div className="space-y-12">
      <div>
        <h2 className="text-3xl font-black uppercase tracking-tighter text-atbu-gold">Cognitive Analytics</h2>
        <p className="text-atbu-gold/40 text-xs font-black uppercase tracking-widest">Real-time pulse of the intellectual ecosystem</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {metrics.map((m, i) => (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            key={m.label}
            className="bg-[#0a0a0a] border-2 border-atbu-gold/10 p-8 rounded-[32px] group hover:border-atbu-gold/40 transition-all relative overflow-hidden"
          >
            <div className="absolute -right-4 -top-4 w-24 h-24 bg-atbu-gold/5 rounded-full blur-2xl group-hover:bg-atbu-gold/10 transition-all" />
            <div className={cn("mb-4 p-3 rounded-xl bg-white/5 inline-block", m.color)}>
              {m.icon}
            </div>
            <p className="text-[10px] font-black uppercase tracking-widest text-atbu-gold/40 mb-1">{m.label}</p>
            <h3 className="text-3xl font-black text-white italic">{m.value}</h3>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Activity Chart Placeholder */}
        <div className="bg-[#0a0a0a] border-2 border-atbu-gold/10 rounded-[40px] p-10 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-black uppercase tracking-tighter text-white italic">Expansion rate</h3>
            <BarChart className="text-atbu-gold/40 w-6 h-6" />
          </div>
          <div className="h-64 flex items-end justify-between gap-4 py-4">
            {[40, 70, 45, 90, 65, 80, 55].map((h, i) => (
              <motion.div 
                initial={{ height: 0 }}
                animate={{ height: `${h}%` }}
                key={i}
                className="w-full bg-atbu-gold/20 rounded-t-xl relative group cursor-help transition-all hover:bg-atbu-gold"
              >
                <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-atbu-gold text-atbu-navy px-2 py-1 rounded text-[8px] font-black opacity-0 group-hover:opacity-100 transition-opacity">
                  {h + 20}%
                </div>
              </motion.div>
            ))}
          </div>
          <div className="flex justify-between text-[8px] font-black uppercase tracking-[0.2em] text-atbu-gold/20">
            <span>Mon</span>
            <span>Tue</span>
            <span>Wed</span>
            <span>Thu</span>
            <span>Fri</span>
            <span>Sat</span>
            <span>Sun</span>
          </div>
        </div>

        {/* Recent Spirits */}
        <div className="bg-[#0a0a0a] border-2 border-atbu-gold/10 rounded-[40px] p-10 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-black uppercase tracking-tighter text-white italic">Recent Manifestations</h3>
            <Award className="text-atbu-gold/40 w-6 h-6" />
          </div>
          <div className="space-y-4">
            {recentLogins.map((user) => (
              <div key={user.id} className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5">
                <div className="flex items-center space-x-3">
                  <img src={user.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.uid}`} className="w-10 h-10 rounded-xl" />
                  <div>
                    <h4 className="text-sm font-black text-white leading-none mb-1">{user.fullName || user.displayName}</h4>
                    <p className="text-[10px] text-atbu-gold/40 font-black uppercase tracking-widest leading-none">{user.department || 'Spirit'}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-xs font-black text-atbu-gold italic">+{user.reputationPoints} RP</p>
                </div>
              </div>
            ))}
          </div>
          <button className="w-full py-4 text-[10px] font-black uppercase tracking-widest text-atbu-gold/40 hover:text-atbu-gold transition-colors">
            View Complete Manifestation Log
          </button>
        </div>
      </div>
    </div>
  );
};
