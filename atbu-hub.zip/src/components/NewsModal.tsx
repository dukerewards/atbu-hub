import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Calendar, User, Newspaper, ExternalLink } from 'lucide-react';
import { CommentsSection } from './CommentsSection';

interface NewsModalProps {
  isOpen: boolean;
  onClose: () => void;
  news: any;
}

export const NewsModal: React.FC<NewsModalProps> = ({ isOpen, onClose, news }) => {
  if (!news) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-atbu-navy/80 backdrop-blur-xl"
          />
          
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="relative w-full max-w-3xl max-h-[90vh] bg-white dark:bg-atbu-navy border border-slate-200 dark:border-white/10 rounded-[40px] shadow-2xl overflow-hidden flex flex-col"
          >
            {/* Header Image/Header */}
            <div className="relative h-48 sm:h-64 bg-atbu-gold/10 overflow-hidden shrink-0">
              {news.fileUrl ? (
                <img 
                  src={news.fileUrl} 
                  alt={news.title}
                  className="w-full h-full object-cover"
                  onError={(e) => e.currentTarget.classList.add('hidden')}
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-atbu-gold/20">
                  <Newspaper className="w-32 h-32" />
                </div>
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-atbu-navy to-transparent" />
              <button 
                onClick={onClose}
                className="absolute top-6 right-6 p-3 rounded-2xl bg-white/10 backdrop-blur-lg text-white hover:bg-white/20 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-8 space-y-8">
              <div className="space-y-4">
                <div className="flex flex-wrap gap-2 text-[10px] font-black uppercase tracking-widest">
                  <span className="px-3 py-1 bg-atbu-gold text-atbu-navy rounded-full">
                    {news.source === 'official' ? 'Official Notice' : 'Student News'}
                  </span>
                  <span className="px-3 py-1 bg-slate-100 dark:bg-white/10 text-slate-500 dark:text-white/40 rounded-full flex items-center">
                    <Calendar className="w-3 h-3 mr-1" />
                    {news.createdAt?.toDate().toLocaleDateString()}
                  </span>
                </div>
                
                <h2 className="text-3xl font-black text-slate-900 dark:text-white leading-tight uppercase tracking-tighter">
                  {news.title || news.headline}
                </h2>
                
                <div className="flex items-center space-x-3 p-3 bg-slate-50 dark:bg-white/5 rounded-2xl border border-slate-100 dark:border-white/5">
                  <div className="w-10 h-10 bg-atbu-gold rounded-xl flex items-center justify-center text-atbu-navy font-bold">
                    <User className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs text-slate-400 dark:text-white/40 font-black uppercase tracking-widest leading-none mb-1">Published By</p>
                    <p className="text-sm font-black text-slate-900 dark:text-white leading-none">{news.author}</p>
                  </div>
                </div>
              </div>

              <div className="prose dark:prose-invert max-w-none">
                <p className="text-slate-600 dark:text-white/70 text-lg leading-relaxed font-medium">
                  {news.content || news.description}
                </p>
              </div>

              {news.fileUrl && (
                <a 
                  href={news.fileUrl} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center justify-center space-x-2 w-full py-4 bg-atbu-gold/10 text-atbu-gold rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-atbu-gold hover:text-atbu-navy transition-all"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>View Attached Resource</span>
                </a>
              )}

              {/* Discussion */}
              <CommentsSection contentId={news.id} title="News Discussion" />
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
