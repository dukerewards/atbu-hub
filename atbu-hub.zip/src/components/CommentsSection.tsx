import React, { useState, useEffect } from 'react';
import { collection, query, where, orderBy, onSnapshot, addDoc, serverTimestamp, deleteDoc, doc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';
import { motion, AnimatePresence } from 'motion/react';
import { MessageSquare, Send, Trash2, Loader2, User } from 'lucide-react';
import { cn } from '../lib/utils';
import { formatDistanceToNow } from 'date-fns';

interface Comment {
  id: string;
  contentId: string;
  userId: string;
  userName: string;
  userPhoto: string;
  text: string;
  createdAt: any;
}

interface CommentsSectionProps {
  contentId: string;
  title?: string;
}

export const CommentsSection: React.FC<CommentsSectionProps> = ({ contentId, title = "Student Discussion" }) => {
  const { user, profile } = useAuth();
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [loading, setLoading] = useState(true);
  const [isSending, setIsSending] = useState(false);

  useEffect(() => {
    const q = query(
      collection(db, 'comments'),
      where('contentId', '==', contentId),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetchedComments = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Comment[];
      setComments(fetchedComments);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [contentId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !newComment.trim() || isSending) return;

    setIsSending(true);
    try {
      await addDoc(collection(db, 'comments'), {
        contentId,
        userId: user.uid,
        userName: profile?.fullName || user.displayName || 'Scholar',
        userPhoto: user.photoURL || '',
        text: newComment.trim(),
        createdAt: serverTimestamp(),
      });
      setNewComment('');
    } catch (error) {
      console.error("Error adding comment:", error);
    } finally {
      setIsSending(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm("Delete this comment?")) return;
    try {
      await deleteDoc(doc(db, 'comments', id));
    } catch (error) {
      console.error("Error deleting comment:", error);
    }
  };

  return (
    <div className="mt-12 space-y-6">
      <div className="flex items-center justify-between border-b border-slate-100 dark:border-white/5 pb-4">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-atbu-gold/10 rounded-xl flex items-center justify-center text-atbu-gold">
            <MessageSquare className="w-5 h-5" />
          </div>
          <h3 className="text-xl font-black text-slate-800 dark:text-white uppercase tracking-tight">{title}</h3>
        </div>
        <span className="px-3 py-1 bg-slate-100 dark:bg-white/5 rounded-full text-[10px] font-black text-slate-500 uppercase tracking-widest">
          {comments.length} Comments
        </span>
      </div>

      {/* Add Comment */}
      {user ? (
        <form onSubmit={handleSubmit} className="relative group">
          <div className="absolute left-4 top-1/2 -translate-y-1/2">
            <img 
              src={user.photoURL || ''} 
              alt="Me" 
              className="w-8 h-8 rounded-xl border border-atbu-gold/20"
              onError={(e) => e.currentTarget.src = "https://ui-avatars.com/api/?name=" + encodeURIComponent(user.displayName || 'S')}
            />
          </div>
          <input
            type="text"
            placeholder="Write a comment..."
            className="w-full pl-16 pr-20 py-5 bg-white dark:bg-white/5 border-2 border-slate-100 dark:border-white/10 rounded-2xl outline-none focus:border-atbu-gold transition-all dark:text-white font-medium"
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
          />
          <button
            type="submit"
            disabled={!newComment.trim() || isSending}
            className="absolute right-3 top-1/2 -translate-y-1/2 p-3 bg-atbu-gold text-atbu-navy rounded-xl shadow-lg shadow-atbu-gold/20 hover:scale-105 active:scale-95 transition-all disabled:opacity-50"
          >
            {isSending ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
          </button>
        </form>
      ) : (
        <div className="p-8 bg-slate-50 dark:bg-white/5 rounded-3xl text-center border-2 border-dashed border-slate-200 dark:border-white/10">
          <p className="text-slate-500 dark:text-white/40 font-bold">Please sign in to join the discussion.</p>
        </div>
      )}

      {/* Comments List */}
      <div className="space-y-4">
        {loading ? (
          <div className="py-8 flex justify-center">
            <Loader2 className="w-6 h-6 animate-spin text-atbu-gold" />
          </div>
        ) : (
          <AnimatePresence>
            {comments.map((comment) => (
              <motion.div
                layout
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                key={comment.id}
                className="p-6 bg-slate-50 dark:bg-white/5 rounded-[30px] border border-slate-100 dark:border-white/5 flex space-x-4 group"
              >
                <img 
                  src={comment.userPhoto} 
                  alt={comment.userName} 
                  className="w-10 h-10 rounded-2xl border-2 border-atbu-gold/10 shrink-0"
                  onError={(e) => e.currentTarget.src = "https://ui-avatars.com/api/?name=" + encodeURIComponent(comment.userName)}
                />
                <div className="flex-1 space-y-1">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-sm font-black text-slate-800 dark:text-white">{comment.userName}</span>
                      {comment.createdAt && (
                        <span className="ml-3 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                          {formatDistanceToNow(comment.createdAt.toDate())} ago
                        </span>
                      )}
                    </div>
                    {user?.uid === comment.userId && (
                      <button 
                        onClick={() => handleDelete(comment.id)}
                        className="p-2 text-slate-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                  <p className="text-slate-600 dark:text-white/70 text-sm leading-relaxed">
                    {comment.text}
                  </p>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        )}

        {!loading && comments.length === 0 && (
          <div className="py-12 text-center text-slate-400 dark:text-white/20">
            <MessageSquare className="w-12 h-12 mx-auto mb-3 opacity-20" />
            <p className="font-bold uppercase tracking-widest text-xs">Be the first to comment</p>
          </div>
        )}
      </div>
    </div>
  );
};
