import React, { useState, useEffect } from 'react';
import { collection, query, orderBy, limit, getDocs, where } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Bell, Calendar, ChevronRight, Megaphone } from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';
import { NewsModal } from './NewsModal';

interface Notice {
  id: string;
  source: 'official' | 'student';
  title: string;
  content: string;
  author: string;
  createdAt: any;
}

export const NoticeBoard = () => {
  const [notices, setNotices] = useState<Notice[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedNotice, setSelectedNotice] = useState<Notice | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const noticesQ = query(collection(db, 'notices'), orderBy('createdAt', 'desc'), limit(5));
        const newsQ = query(
          collection(db, 'campusContent'), 
          where('type', '==', 'news'), 
          where('status', '==', 'approved'),
          orderBy('createdAt', 'desc'), 
          limit(5)
        );
        
        const [noticesSnap, newsSnap] = await Promise.all([
          getDocs(noticesQ),
          getDocs(newsQ)
        ]);

        const fetchedNotices = noticesSnap.docs.map(doc => ({
          id: doc.id,
          source: 'official',
          ...doc.data()
        }));

        const fetchedNews = newsSnap.docs.map(doc => ({
          id: doc.id,
          source: 'student',
          title: doc.data().headline,
          content: doc.data().description,
          author: doc.data().uploaderName,
          ...doc.data()
        }));

        const combined = [...fetchedNotices, ...fetchedNews].sort((a: any, b: any) => 
          b.createdAt?.toDate().getTime() - a.createdAt?.toDate().getTime()
        ).slice(0, 8);

        setNotices(combined as any);
      } catch (error) {
        console.error("Error fetching notices:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const displayNotices = notices.length > 0 ? notices : [
    { 
      id: '1', 
      title: 'Revision of 2023/2024 Academic Calendar', 
      content: 'The Senate has approved the revision of the academic calendar for the second semester...', 
      author: 'Registrar',
      createdAt: { toDate: () => new Date() }
    },
    { 
      id: '2', 
      title: 'Registration Deadline Extended', 
      content: 'Students are hereby informed that the deadline for course registration has been extended by two weeks.', 
      author: 'Academic Affairs',
      createdAt: { toDate: () => new Date(Date.now() - 86400000) }
    },
    { 
      id: '3', 
      title: 'Warning on Indecent Dressing', 
      content: 'The University Management has observed with concern the rising cases of indecent dressing on campus...', 
      author: 'Security Division',
      createdAt: { toDate: () => new Date(Date.now() - 172800000) }
    }
  ];

  return (
    <div className="premium-card overflow-hidden border-white/10">
      <div className="glass-card !bg-atbu-navy/80 p-6 flex items-center justify-between border-none">
        <div className="flex items-center space-x-3 text-atbu-gold">
          <Megaphone className="w-6 h-6" />
          <h2 className="text-xl font-black uppercase tracking-tighter">Official Pulse</h2>
        </div>
        <div className="bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 px-2 py-1 rounded-[4px] text-[10px] font-black tracking-widest animate-pulse">
          LIVE
        </div>
      </div>
      
      <div className="divide-y divide-white/5">
        {displayNotices.map((notice, index) => (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            key={notice.id}
            onClick={() => setSelectedNotice(notice)}
            className="p-6 hover:bg-white/5 transition-all cursor-pointer group"
          >
            <div className="flex items-start justify-between">
              <div className="space-y-1">
                <div className="flex flex-wrap items-center gap-2 text-xs font-medium mb-2">
                  <span className={cn(
                    "px-2 py-0.5 rounded-[4px] text-[80.2%] font-black uppercase tracking-widest",
                    notice.source === 'official' 
                      ? "bg-atbu-navy text-atbu-gold border border-atbu-gold/20" 
                      : "bg-atbu-gold/10 text-atbu-gold border border-atbu-gold/20"
                  )}>
                    {notice.source === 'official' ? 'Official' : 'Student News'}
                  </span>
                  <div className="flex items-center space-x-1 text-white/40">
                    <Calendar className="w-3 h-3" />
                    <span>{notice.createdAt?.toDate().toLocaleDateString()}</span>
                  </div>
                </div>
                <h3 className="font-bold text-white group-hover:text-atbu-gold transition-colors line-clamp-1 uppercase tracking-tight">
                  {notice.title}
                </h3>
                <p className="text-sm text-white/40 line-clamp-2 italic font-medium">
                  "{notice.content}"
                </p>
              </div>
              <ChevronRight className="w-5 h-5 text-white/20 group-hover:text-atbu-gold transition-colors shrink-0 self-center" />
            </div>
          </motion.div>
        ))}
      </div>
      
      <div className="p-4 bg-white/2 text-center">
        <button className="text-atbu-gold font-black uppercase tracking-widest text-[10px] hover:text-white transition-colors flex items-center justify-center mx-auto">
          View All Announcements <ChevronRight className="w-4 h-4 ml-1" />
        </button>
      </div>

      <NewsModal 
        isOpen={!!selectedNotice} 
        onClose={() => setSelectedNotice(null)} 
        news={selectedNotice} 
      />
    </div>
  );
};
