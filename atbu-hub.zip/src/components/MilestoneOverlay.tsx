import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Award, Star, X } from 'lucide-react';

export const MilestoneOverlay: React.FC<{ points: number }> = ({ points }) => {
  const [show, setShow] = useState(false);
  const [milestone, setMilestone] = useState(0);

  useEffect(() => {
    if (points > 0 && points % 50 === 0) {
      setMilestone(points);
      setShow(true);
      const timer = setTimeout(() => setShow(false), 5000);
      return () => clearTimeout(timer);
    }
  }, [points]);

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ opacity: 0, y: 50, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, scale: 0.5 }}
          className="fixed bottom-8 left-1/2 -translate-x-1/2 z-[100] bg-atbu-navy border-2 border-atbu-gold p-6 rounded-3xl shadow-2xl flex items-center space-x-6 min-w-[320px]"
        >
          <div className="bg-atbu-gold/20 p-3 rounded-2xl">
            <Award className="w-10 h-10 text-atbu-gold" />
          </div>
          <div className="flex-grow">
            <h3 className="text-white font-bold text-lg leading-tight">New Milestone!</h3>
            <p className="text-atbu-gold text-sm font-medium">You've reached {milestone} Reputation Points!</p>
          </div>
          <button onClick={() => setShow(false)} className="text-white/20 hover:text-white">
            <X className="w-5 h-5" />
          </button>
          
          {/* Confetti-like effect */}
          <div className="absolute inset-0 pointer-events-none overflow-hidden rounded-3xl">
            {[1, 2, 3, 4, 5].map(i => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 0 }}
                animate={{ opacity: [0, 1, 0], y: -50, x: (i - 3) * 20 }}
                transition={{ duration: 2, repeat: Infinity, delay: i * 0.2 }}
                className="absolute bottom-0 left-1/2 text-atbu-gold"
              >
                <Star className="w-4 h-4 fill-current" />
              </motion.div>
            ))}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
