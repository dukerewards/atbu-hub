import React from 'react';
import { Navbar } from './Navbar';
import { AdManager } from './AdManager';
import { motion } from 'motion/react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const navigate = useNavigate();
  const { profile } = useAuth();

  const handleAdminSecret = () => {
    if (profile?.email === 'emmanuelnefa2006@gmail.com') {
      navigate('/duke-vault');
    }
  };

  return (
    <div className="min-h-screen flex flex-col font-sans selection:bg-atbu-gold selection:text-atbu-navy">
      <Navbar />
      <AdManager />
      <motion.main
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
        className="flex-grow max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-40 pb-20 w-full"
      >
        {children}
      </motion.main>
      <footer className="glass-card !rounded-none border-x-0 border-b-0 py-12 relative overflow-hidden mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-6 md:space-y-0">
            <div className="text-center md:text-left">
              <span className="text-white font-black tracking-tighter text-2xl">ATBU<span className="text-atbu-gold">HUB</span></span>
              <p className="text-white/20 text-[10px] font-black uppercase tracking-[0.4em] mt-1">Official Student Elite Portal</p>
            </div>
            <div className="flex space-x-8 text-[10px] font-black uppercase tracking-widest text-white/40">
              <span className="hover:text-atbu-gold cursor-pointer transition-colors">Digital Library</span>
              <span className="hover:text-atbu-gold cursor-pointer transition-colors">Elite Marketplace</span>
              <span className="hover:text-atbu-gold cursor-pointer transition-colors">Privacy protocol</span>
            </div>
            <div className="flex space-x-8 text-[10px] font-black uppercase tracking-[0.2em] text-white/20">
              <a href="/about" className="hover:text-atbu-gold transition-colors">About</a>
              <a href="/library" className="hover:text-atbu-gold transition-colors">Library</a>
              <a href="/market" className="hover:text-atbu-gold transition-colors">Market</a>
            </div>
            <p className="text-[10px] text-white/20 font-black uppercase tracking-widest">© {new Date().getFullYear()} ATBU HUB</p>

          </div>
        </div>

        {/* The Secret Door - Duke */}
        <button
          onClick={handleAdminSecret}
          className="absolute bottom-4 right-4 text-[7px] font-black tracking-[0.3em] uppercase transition-all duration-700 select-none cursor-default text-transparent hover:text-white/5 focus:outline-none"
          aria-hidden="true"
        >
          Duke
        </button>
      </footer>
    </div>
  );
};
