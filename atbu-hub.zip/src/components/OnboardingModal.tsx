import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../contexts/AuthContext';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { doc, updateDoc } from 'firebase/firestore';
import { User, ChevronRight, CheckCircle2, GraduationCap, ArrowRight } from 'lucide-react';
import { cn } from '../lib/utils';

export const OnboardingModal: React.FC = () => {
  const { user, profile, needsOnboarding, refreshProfile } = useAuth();
  const [step, setStep] = useState(1);
  const [fullName, setFullName] = useState(profile?.displayName || '');
  const [gender, setGender] = useState('');
  const [department, setDepartment] = useState('');
  const [loading, setLoading] = useState(false);

  if (!needsOnboarding) return null;

  const handleComplete = async () => {
    if (!user) return;
    const docPath = `users/${user.uid}`;
    setLoading(true);
    try {
      await updateDoc(doc(db, 'users', user.uid), {
        fullName,
        gender,
        department,
        reputationPoints: 25 // Bonus for completing registration
      });
      await refreshProfile();
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, docPath);
    } finally {
      setLoading(false);
    }
  };

  const nextStep = () => {
    if (step === 1 && !fullName.trim()) return;
    if (step === 2 && !gender) return;
    if (step < 3) setStep(step + 1);
    else handleComplete();
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="absolute inset-0 bg-atbu-navy/95 backdrop-blur-xl"
      />
      
      <motion.div 
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative w-full max-w-lg bg-white p-12 rounded-[50px] shadow-2xl overflow-hidden"
      >
        {/* Progress Bar */}
        <div className="absolute top-0 left-0 w-full h-2 bg-slate-100 flex">
          {[1, 2, 3].map(i => (
            <div 
              key={i} 
              className={cn(
                "flex-grow transition-all duration-500",
                step >= i ? "bg-atbu-gold" : "bg-transparent"
              )} 
            />
          ))}
        </div>

        <div className="space-y-8">
          <AnimatePresence mode="wait">
            {step === 1 && (
              <motion.div
                key="step1"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="space-y-2">
                  <h2 className="text-3xl font-black text-atbu-navy">Welcome, Scholar.</h2>
                  <p className="text-slate-500 font-medium tracking-tight">Let's start with your official full name as it appears on your registration.</p>
                </div>
                
                <div className="relative">
                  <User className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300 w-5 h-5" />
                  <input
                    type="text"
                    placeholder="Full Legal Name"
                    className="w-full pl-14 pr-6 py-5 bg-slate-50 border-2 border-slate-100 rounded-3xl outline-none focus:border-atbu-gold transition-all text-xl font-bold text-atbu-navy"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    autoFocus
                  />
                </div>
              </motion.div>
            )}

            {step === 2 && (
              <motion.div
                key="step2"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="space-y-2">
                  <h2 className="text-3xl font-black text-atbu-navy">Identity Profile.</h2>
                  <p className="text-slate-500 font-medium tracking-tight">Please select your gender for community verification.</p>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  {['Male', 'Female'].map(g => (
                    <button
                      key={g}
                      onClick={() => setGender(g)}
                      className={cn(
                        "p-8 rounded-[30px] border-2 transition-all flex flex-col items-center space-y-4 group",
                        gender === g ? "bg-atbu-navy border-atbu-navy text-atbu-gold shadow-2xl" : "bg-slate-50 border-slate-50 text-slate-400 hover:border-atbu-gold"
                      )}
                    >
                      <div className={cn(
                        "w-12 h-12 rounded-2xl flex items-center justify-center transition-colors",
                        gender === g ? "bg-atbu-gold text-atbu-navy" : "bg-white text-slate-300"
                      )}>
                        <User className="w-6 h-6" />
                      </div>
                      <span className="font-black uppercase tracking-[0.2em] text-xs">{g}</span>
                    </button>
                  ))}
                </div>
              </motion.div>
            )}

            {step === 3 && (
              <motion.div
                key="step3"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="space-y-2">
                  <h2 className="text-3xl font-black text-atbu-navy">Department.</h2>
                  <p className="text-slate-500 font-medium tracking-tight">Which department do you belong to? (You can skip this for now)</p>
                </div>
                
                <div className="relative">
                  <GraduationCap className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300 w-5 h-5" />
                  <input
                    type="text"
                    placeholder="e.g. Computer Science"
                    className="w-full pl-14 pr-6 py-5 bg-slate-50 border-2 border-slate-100 rounded-3xl outline-none focus:border-atbu-gold transition-all text-xl font-bold text-atbu-navy"
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    autoFocus
                  />
                </div>

                <div className="flex justify-center">
                  <button 
                    onClick={handleComplete}
                    className="text-slate-300 text-sm font-bold hover:text-atbu-gold transition-colors"
                  >
                    I'll add this later
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <button
            onClick={nextStep}
            disabled={loading || (step === 1 && !fullName.trim()) || (step === 2 && !gender)}
            className="w-full bg-atbu-navy text-atbu-gold font-black py-6 rounded-3xl flex items-center justify-center space-x-3 hover:scale-[1.02] active:scale-95 transition-all shadow-2xl disabled:opacity-50"
          >
            <span>{step === 3 ? 'FINISH & ENTER HUB' : 'CONTINUE'}</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </motion.div>
    </div>
  );
};
