import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShieldCheck, X, ChevronRight, GraduationCap } from 'lucide-react';
import { signInWithGoogle } from '../lib/firebase';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  subtitle?: string;
}

export const LoginModal: React.FC<LoginModalProps> = ({ 
  isOpen, 
  onClose, 
  title = "Join the ATBU Academic Elite",
  subtitle = "Unlock full access to course materials, practice tests, and the student marketplace."
}) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-atbu-navy/80 backdrop-blur-md"
          />
          
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="relative w-full max-w-md bg-white/5 backdrop-blur-2xl border border-white/10 p-8 rounded-[40px] shadow-2xl overflow-hidden"
          >
            {/* Gold Accent Glow */}
            <div className="absolute -top-24 -left-24 w-48 h-48 bg-atbu-gold/20 rounded-full blur-[80px]" />
            <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-atbu-gold/10 rounded-full blur-[80px]" />

            <button 
              onClick={onClose}
              className="absolute top-6 right-6 text-white/40 hover:text-white transition-colors"
            >
              <X className="w-6 h-6" />
            </button>

            <div className="flex flex-col items-center text-center space-y-6 relative z-10">
              <div className="w-16 h-16 bg-atbu-gold/10 rounded-[20px] flex items-center justify-center border border-atbu-gold/20 shadow-lg shadow-atbu-gold/5">
                <ShieldCheck className="w-8 h-8 text-atbu-gold" />
              </div>
              
              <div className="space-y-2">
                <h2 className="text-2xl font-black text-white tracking-tight leading-tight">
                  {title}
                </h2>
                <p className="text-slate-400 text-sm font-medium px-4">
                  {subtitle}
                </p>
              </div>

              <div className="w-full space-y-3 pt-4">
                <button
                  onClick={() => {
                    signInWithGoogle();
                    onClose();
                  }}
                  className="w-full h-14 bg-white text-atbu-navy font-bold rounded-2xl flex items-center justify-center space-x-3 hover:bg-atbu-gold transition-all group overflow-hidden relative active:scale-95"
                >
                  <img 
                    src="https://www.google.com/favicon.ico" 
                    alt="Google" 
                    className="w-5 h-5" 
                  />
                  <span>Sign in with Google</span>
                  <div className="absolute inset-0 bg-atbu-gold opacity-0 group-hover:opacity-100 transition-opacity -z-10" />
                </button>
                
                <p className="text-[10px] text-white/20 uppercase tracking-[0.2em] font-black">
                  Official ATBU Student Portal Access
                </p>
              </div>

              <div className="pt-6 grid grid-cols-2 gap-4 w-full border-t border-white/5">
                <div className="flex flex-col items-center space-y-1">
                  <span className="text-atbu-gold font-bold text-lg">15k+</span>
                  <span className="text-white/40 text-[10px] font-black uppercase">Students</span>
                </div>
                <div className="flex flex-col items-center space-y-1">
                  <span className="text-atbu-gold font-bold text-lg">500+</span>
                  <span className="text-white/40 text-[10px] font-black uppercase">Manuals</span>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
