import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle2, ChevronLeft, ChevronRight, Clock, HelpCircle, RefreshCcw, Send } from 'lucide-react';
import { cn } from '../lib/utils';

interface Question {
  question: string;
  options: string[];
  correctAnswer: number;
}

interface QuizProps {
  courseCode: string;
  title: string;
  questions: Question[];
  onComplete: (score: number) => void;
  onExit: () => void;
}

export const CBTQuizEngine: React.FC<QuizProps> = ({ courseCode, title, questions, onComplete, onExit }) => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [timeLeft, setTimeLeft] = useState(600); // 10 minutes
  const [showResults, setShowResults] = useState(false);
  const [score, setScore] = useState(0);

  useEffect(() => {
    if (timeLeft > 0 && !showResults) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0) {
      handleFinish();
    }
  }, [timeLeft, showResults]);

  const handleAnswer = (optionIndex: number) => {
    setSelectedAnswers({ ...selectedAnswers, [currentQuestion]: optionIndex });
  };

  const handleFinish = () => {
    let finalScore = 0;
    questions.forEach((q, idx) => {
      if (selectedAnswers[idx] === q.correctAnswer) finalScore++;
    });
    setScore(finalScore);
    setShowResults(true);
    onComplete(finalScore);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (showResults) {
    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-3xl p-8 border border-slate-100 shadow-2xl text-center"
      >
        <div className="w-20 h-20 bg-atbu-gold/20 rounded-full flex items-center justify-center mx-auto mb-6 text-atbu-gold">
          <CheckCircle2 className="w-12 h-12" />
        </div>
        <h2 className="text-3xl font-bold text-atbu-navy mb-2">Practice Completed!</h2>
        <p className="text-slate-500 mb-8">Great job on finishing the {courseCode} practice test.</p>
        
        <div className="grid grid-cols-2 gap-4 mb-8">
          <div className="bg-slate-50 p-4 rounded-2xl">
            <span className="block text-xs font-bold text-slate-400 uppercase">Score</span>
            <span className="text-2xl font-black text-atbu-blue">{score} / {questions.length}</span>
          </div>
          <div className="bg-slate-50 p-4 rounded-2xl">
            <span className="block text-xs font-bold text-slate-400 uppercase">Accuracy</span>
            <span className="text-2xl font-black text-atbu-gold">{Math.round((score / questions.length) * 100)}%</span>
          </div>
        </div>

        <div className="flex flex-col gap-3">
          <button 
            onClick={onExit}
            className="w-full bg-atbu-navy text-white font-bold py-3 rounded-xl hover:bg-atbu-blue transition-all"
          >
            Back to Dashboard
          </button>
          <button 
            onClick={() => {
              setCurrentQuestion(0);
              setSelectedAnswers({});
              setTimeLeft(600);
              setShowResults(false);
            }}
            className="w-full flex items-center justify-center space-x-2 text-atbu-blue font-bold py-3"
          >
            <RefreshCcw className="w-4 h-4" />
            <span>Try Again</span>
          </button>
        </div>
      </motion.div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="flex items-center justify-between bg-white px-6 py-4 rounded-2xl border border-slate-100 shadow-sm">
        <div className="flex items-center space-x-3">
          <button onClick={onExit} className="p-2 hover:bg-slate-50 rounded-lg text-slate-400">
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div>
            <h3 className="font-bold text-atbu-navy">{title}</h3>
            <span className="text-xs font-bold text-atbu-gold uppercase tracking-widest">{courseCode}</span>
          </div>
        </div>
        <div className="flex items-center space-x-3 bg-atbu-navy text-atbu-gold px-4 py-2 rounded-xl">
          <Clock className="w-4 h-4" />
          <span className="font-mono font-bold">{formatTime(timeLeft)}</span>
        </div>
      </div>

      <div className="bg-white rounded-3xl p-8 border border-slate-100 shadow-xl min-h-[400px] flex flex-col justify-between">
        <div className="space-y-8">
          <div className="flex items-center space-x-2 text-atbu-blue font-bold px-3 py-1 bg-atbu-blue/5 rounded-lg w-fit">
            <HelpCircle className="w-4 h-4" />
            <span>Question {currentQuestion + 1} of {questions.length}</span>
          </div>
          
          <h2 className="text-2xl font-bold text-slate-800 leading-relaxed">
            {questions[currentQuestion].question}
          </h2>

          <div className="grid grid-cols-1 gap-3">
            {questions[currentQuestion].options.map((option, idx) => (
              <button
                key={idx}
                onClick={() => handleAnswer(idx)}
                className={cn(
                  "flex items-center p-4 rounded-xl border-2 transition-all text-left group",
                  selectedAnswers[currentQuestion] === idx 
                    ? "bg-atbu-blue text-white border-atbu-blue" 
                    : "bg-white border-slate-100 hover:border-atbu-gold/50"
                )}
              >
                <div className={cn(
                  "w-8 h-8 rounded-lg flex items-center justify-center font-bold mr-4 shrink-0 transition-colors",
                  selectedAnswers[currentQuestion] === idx ? "bg-white/20" : "bg-slate-100 text-slate-400 group-hover:bg-atbu-gold/10 group-hover:text-atbu-gold"
                )}>
                  {String.fromCharCode(65 + idx)}
                </div>
                <span className="font-medium">{option}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center justify-between mt-12 pt-6 border-t border-slate-50">
          <button 
            disabled={currentQuestion === 0}
            onClick={() => setCurrentQuestion(v => v - 1)}
            className="flex items-center space-x-2 text-slate-400 font-bold disabled:opacity-30"
          >
            <ChevronLeft className="w-5 h-5" />
            <span>Previous</span>
          </button>
          
          {currentQuestion === questions.length - 1 ? (
            <button 
              onClick={handleFinish}
              className="bg-green-600 text-white font-bold px-8 py-3 rounded-xl hover:bg-green-700 transition-all flex items-center space-x-2 shadow-lg shadow-green-600/20"
            >
              <Send className="w-4 h-4" />
              <span>Finish Practice</span>
            </button>
          ) : (
            <button 
              onClick={() => setCurrentQuestion(v => v + 1)}
              className="flex items-center space-x-2 text-atbu-blue font-bold"
            >
              <span>Next Question</span>
              <ChevronRight className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>

      <div className="flex flex-wrap gap-2 justify-center">
        {questions.map((_, idx) => (
          <button
            key={idx}
            onClick={() => setCurrentQuestion(idx)}
            className={cn(
              "w-8 h-8 rounded-lg text-xs font-bold transition-all border",
              currentQuestion === idx ? "bg-atbu-navy text-atbu-gold border-atbu-navy" :
              selectedAnswers[idx] !== undefined ? "bg-atbu-gold/20 text-atbu-gold border-atbu-gold/30" :
              "bg-slate-50 text-slate-300 border-slate-100"
            )}
          >
            {idx + 1}
          </button>
        ))}
      </div>
    </div>
  );
};
