export const AD_CONFIG = {
  // Replace these with your actual Monetag Zone IDs
  VIGNETTE_ID: "vignette_zone_123",
  POPUNDER_ID: "popunder_zone_456",
  PUSH_ID: "push_zone_789",
  BANNER_ID: "banner_zone_012",
  
  // Timing settings (in seconds)
  VIGNETTE_INTERVAL: 180, // 3 minutes
  POPUNDER_COOLDOWN: 120, // 2 minutes
  PUSH_INTERVAL: 60,      // 1 minute
  BANNER_REFRESH: 60,     // 1 minute
};
