import React, { Suspense, lazy } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { ThemeProvider } from './contexts/ThemeContext';
import { Layout } from './components/Layout';
import { MilestoneOverlay } from './components/MilestoneOverlay';
import { OnboardingModal } from './components/OnboardingModal';

// Lazy load pages for performance
const Home = lazy(() => import('./pages/Home'));
const Library = lazy(() => import('./pages/Library'));
const Market = lazy(() => import('./pages/Market'));
const Profile = lazy(() => import('./pages/Profile'));
const Leaderboard = lazy(() => import('./pages/Leaderboard'));
const Quizzes = lazy(() => import('./pages/Quizzes'));
const ChatSpace = lazy(() => import('./pages/ChatSpace'));
const AdminDashboard = lazy(() => import('./pages/AdminDashboard'));
const About = lazy(() => import('./pages/About'));

const AppContent = () => {
  const { profile } = useAuth();
  return (
    <Routes>
      {/* Admin Route - No standard layout */}
      <Route path="/duke-vault/*" element={
        <Suspense fallback={<div className="bg-[#050505] min-h-screen" />}>
          <AdminDashboard />
        </Suspense>
      } />

      {/* Main Student Routes */}
      <Route path="/*" element={
        <Layout>
          <Suspense fallback={
            <div className="flex justify-center items-center h-screen">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-atbu-gold"></div>
            </div>
          }>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/library" element={<Library />} />
              <Route path="/market" element={<Market />} />
              <Route path="/profile" element={<Profile />} />
              <Route path="/leaderboard" element={<Profile />} />
              <Route path="/quizzes" element={<Quizzes />} />
              <Route path="/chat" element={<ChatSpace />} />
              <Route path="/about" element={<About />} />
            </Routes>
          </Suspense>
          {profile && <MilestoneOverlay points={profile.reputationPoints} />}
          <OnboardingModal />
        </Layout>
      } />
    </Routes>
  );
};

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <Router>
          <AppContent />
        </Router>
      </AuthProvider>
    </ThemeProvider>
  );
}
