importScripts('https://www.gstatic.com/firebasejs/10.0.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.0.0/firebase-messaging-compat.js');

// These config fields should ideally be fetched from the config file, 
// but for the service worker we'll use the ones from the config we have.
// Note: In a real app, you might build this file via a script to inject the values.
/* CONFIG_START */
firebase.initializeApp({
  apiKey: "AIzaSyAeHOcF_91VTG5ngLyHA8p92CHk70smjPQ",
  authDomain: "gen-lang-client-0408706416.firebaseapp.com",
  projectId: "gen-lang-client-0408706416",
  storageBucket: "gen-lang-client-0408706416.firebasestorage.app",
  messagingSenderId: "782401412897",
  appId: "1:782401412897:web:f4185a9d7cc63b55c72860",
  measurementId: ""
});
/* CONFIG_END */

const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
  console.log('[firebase-messaging-sw.js] Received background message ', payload);
  const notificationTitle = payload.notification.title;
  const notificationOptions = {
    body: payload.notification.body,
    icon: '/favicon.ico'
  };

  self.registration.showNotification(notificationTitle, notificationOptions);
});
